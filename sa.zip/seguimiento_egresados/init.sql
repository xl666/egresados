-- MySQL dump 10.13  Distrib 8.0.21, for osx10.15 (x86_64)
--
-- Host: localhost    Database: control_egresados
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alumno`
--
USE control_egresados;

DROP TABLE IF EXISTS `alumno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alumno` (
  `matricula` varchar(10) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellido_paterno` varchar(45) NOT NULL,
  `genero` varchar(10) DEFAULT NULL,
  `fecha_nacimiento` date NOT NULL,
  `estado_civil` varchar(45) DEFAULT NULL,
  `correo` varchar(45) NOT NULL,
  `correo_uv` varchar(45) NOT NULL,
  `celular` varchar(45) DEFAULT NULL,
  `twitter` varchar(45) DEFAULT NULL,
  `facebook` varchar(45) DEFAULT NULL,
  `calle` varchar(45) DEFAULT NULL,
  `colonia` varchar(45) DEFAULT NULL,
  `numero` varchar(45) DEFAULT NULL,
  `codigo_postal` varchar(15) DEFAULT NULL,
  `id_estado` int DEFAULT NULL,
  `id_municipio` int DEFAULT NULL,
  `apellido_materno` varchar(45) NOT NULL,
  PRIMARY KEY (`matricula`),
  KEY `fk_alumno_estados1` (`id_estado`),
  KEY `fk_alumno_municipios1` (`id_municipio`),
  CONSTRAINT `fk_alumno_estados1` FOREIGN KEY (`id_estado`) REFERENCES `estados` (`id_estado`),
  CONSTRAINT `fk_alumno_municipios1` FOREIGN KEY (`id_municipio`) REFERENCES `municipios` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alumno`
--

LOCK TABLES `alumno` WRITE;
/*!40000 ALTER TABLE `alumno` DISABLE KEYS */;
INSERT INTO `alumno` VALUES ('S14011599','Mauricio','Juárez ','M','1996-01-29',NULL,'mau_96129@hotmail.com','zS14011599@estudiantes.uv.mx','2282699004','','Mauricio Juárez Capistran','El Sabino, Piletas ',NULL,'6','91315',30,2227,'Capistran'),('S14011607','Gerardo','Martínez','M','1994-09-28',NULL,'gmartzte@gmail.com','zS14011607@estudiantes.uv.mx','2283041221','@gmartzte','','Avenida Ciudad de lado Flores Colonia Revoluc',NULL,'165','91100',30,2291,'Zárate'),('s14011609','Ossiel','Niembro','M','1995-09-01',NULL,'ossielniembrogarcia@gmail.com','zS14011609@estudiantes.uv.mx','2281264372','@OssielNiembro','Ossiel Niembro  Garcia','Miguel Hidalgo,Centro',NULL,'25','91300',30,2113,'Garcia'),('S14011623','Missael','Hernández','M','1996-03-09',NULL,'missaelxp@gmail.com','zS14000000@estudiantes.uv.mx','2281717935','@missaelxp','Missael Hernández','Francisco I. Madero Col. Emiliano Zapata',NULL,'4','91090',30,2291,'Rosado'),('S14011631','Renato','Vargas','M','1996-01-03',NULL,'ALBRK@protonmail.com','zS14011631@estudiantes.uv.mx','2281252248','@ALBRK1','','Guillermo Soto Colorado',NULL,'25','91095',9,276,'Gómez'),('s14011632','Susana','González ','F','1994-02-14',NULL,'susana-140294@hotmail.com','zS14011632@estudiantes.uv.mx','2282290191','@susana1249','Susana González ','Av. Paseo Xalapa',NULL,'96','91158',30,2291,'Portilla'),('S14011633','Rodrigo','Ruiz','M','1994-10-27',NULL,'yor_27@hotmail.com','ZS14011633@estudiantes.uv.mx','2281560111','@yoresroy','Rodrigo Ruiz Salmorán','Chilpancingo',NULL,'610','91130',30,2291,'Salmorán'),('S14011634','Ana Paola ','Cházaro ','F','1996-01-27',NULL,'ap96_voley@live.com.mx','zS14011634@estudiantes.uv.mx','2281772352','@anapaolacw','Ana Paola Cházaro Watty','Río Vinazco',NULL,'85','91065',19,996,'Watty'),('s14011635','Miguel Angel','Acosta','M','1994-12-12',NULL,'miguelacosta1294@outlook.com','zS14000000@estudiantes.uv.mx','2281014002','@Migueelacosta','Migueel Acosta','Rio amazonas Col. Carolino Anaya',NULL,'111','91158',30,2291,'Aparicio'),('s14011642','Erasmo Carlos','Torres','M','1995-08-31',NULL,'erasmocts@gmail.com','zS14011642@estudiantes.uv.mx','2281133221','@nusok','Carlos Torres','Antonio Perez Rivera ',NULL,'61','91170',30,2291,'Sanromán'),('S14011661','Víctor Hugo','Hernández','M','1996-04-04',NULL,'victor_hdez96@hotmail.com','zS14011661@estudiantes.uv.mx','2282820960','@ElHuguito96','https://www.facebook.com/elhuguito96','Cristobal Rodriguez, Col. Obrero Campesina',NULL,'202','91020',30,2291,'Hoyos'),('S14013576','Marcos Iván','Rivera ','M','1994-09-05',NULL,'ivanrgomez05@gmail.com','zS14013576@estudiantes.uv.mx','2282414687','@ivanriivera','Iván Rivera ','Calle cormoranes ',NULL,'26','91098',30,2291,'Gómez'),('S14013577','Erick Javier','Reyes','M','1995-08-09',NULL,'chitoryz@gmail.com','zs14013577@estudiantes.uv.mx','2281021659','','','Prolongación Esteban Mascareñas',NULL,'39','91094',30,2179,'Reyes'),('S14013604','Cecilia','Martínez','F','1995-04-22',NULL,'cmartinezm_1ero@hotmail.com','zS14013604@estudiantes.uv.mx','2323261073','','','C. Miguel Hidalgo Col. Amador Torres',NULL,'131','93650',30,2276,'Martínez'),('S14013616','Vania','Mora','F','1995-11-14',NULL,'moravania95@gmail.com','zS14013616@estudiantes.uv.mx','2281310242','@vaanimora','Vaani Mora','Av. Chedraui Caram ',NULL,'147','91155',30,2291,'Velázquez'),('s15011608','Alba Cristina','Garza','F','1997-12-06',NULL,'cristina.garza06@hotmail.com','zS15011608@estudiantes.uv.mx','2288266909','','Cristina Garza Cayetano','Manlio Fabio Altamirano',NULL,'129','91000',30,2132,'Cayetano'),('S15011611','Esmeralda Yamileth ','Hernández','F','1997-08-17',NULL,'esmeyhg@gmail.com','zS15011611@estudiantes.uv.mx','4074276382','','Esmeralda hdez','Ruiz Cortines',NULL,'1096','91020',30,2291,'González '),('S15011612','Irvin Dereb','Vera','M','1993-12-13',NULL,'irdevelo@gmail.com','zS15011612@estudiantes.uv.mx','2281915425','','Irvin Vera','Jorullo',NULL,'71','91130',30,2291,'López'),('s15011613','José Andrés','Domínguez','M','1996-12-20',NULL,'andresdglez@gmail.com','zS15011613@estudiantes.uv.mx','2282430840','@_andres_dglez','','Pamir, Casa Blanca',NULL,'10','91155',30,2291,'González'),('S15011617','Jesús Enrique','Flores','M','1993-05-24',NULL,'enrique.flores093@gmail.com','zS15011617@estudiantes.uv.mx','9211476258','@EnriqueNestozo','Jesús Enrique Flores Nestozo','Av. Xalapeños ilustres',NULL,'160','91100',30,2140,'Nestozo'),('S15011621','Miguel Leonardo','Jiménez','M','1997-09-16',NULL,'miguel.leonardo037@gmail.com','zS15011621@estudiantes.uv.mx','2281152023','@MLeonardo037','Leonardo Jimenez','Calle Morelos, Rancho Viejo',NULL,'S/N','91636',30,2155,'Jiménez'),('s15011623','Adrian','Bustamante','M','1997-12-07',NULL,'arkadwn@gmail.com','zS15011623@estudiantes.uv.mx','2281879537','@AdrianBtteJr','Adrian Bustamante','Ebano, Unidad del bosque',NULL,'17','91017',30,2291,'Zarate'),('S15011624','Ángel Eduardo','Domínguez','M','1996-10-18',NULL,'lalo_dd@hotmail.com','zS15011624@estudiantes.uv.mx','2281328070','@eduard0x18','Ángel Domínguez','Carlos 1',NULL,'5','91100',30,2291,'Delgado'),('S15011638','Alan Yoset','Garcia','M','1995-08-17',NULL,'alancrux_@hotmail.com','zS15011638@estudiantes.uv.mx','2283038916','@alancrux_','Alan Yoset Garcia Cruz','Miguel Dorantes Mesa ',NULL,'28','91130',30,2291,'Cruz'),('S15011639','José Alonso','Lora','M','1997-07-25',NULL,'alonsolorastarr@gmail.com','zS15011639@estudiantes.uv.mx','2282770141','@lora_alonso','Alonso Lora','Hilario C Salas',NULL,'319B','91055',30,2291,'González'),('s15011641','Víctor Javier','García','M','1997-04-23',NULL,'vijagama@outlook.es','zS15011641@estudiantes.uv.mx','2281843459','@VictorGJMascareñas','Víctor J. G. Mascareñas','Calle Mata Obscura s/n, Col. El Lencero. Emil',NULL,'s/n','91634',28,2024,'Mascareñas'),('S15011647','Zaret Sahar Jahzeel','Roque','M','1997-02-18',NULL,'zaret_roque@hotmail.com','zS15011647@estudiantes.uv.mx','2288397315','No lo utilizo','No lo utilizo','Jazmin, Las Azaleas',NULL,'24','91500',30,2291,'---'),('S15011651','Israel','Reyes','M','1997-04-19',NULL,'iro1904@hotmail.com','zS15011651@estudiantes.uv.mx','2281228021','Isrozuna','Israel Ozuna','Cayetano Rodríguez Beltrán, Fracc Lucas Martí',NULL,'52','91100',30,2291,'Ozuna'),('S15011663','Raymundo de Jesús','Pérez','M','1996-12-19',NULL,'raymundo170@hotmail.com','zs15011663@estudiantes.uv.mx','2288397419','','Ray Jpc','Sayago, Centro',NULL,'190','91000',30,2291,'Castellanos'),('s15011664','Maribel','Tello','F','1997-07-07',NULL,'mari_campana7_@hotmail.com','zS15011664@estudiantes.uv.mx','2288462342','','Mari Tello','Edificio Macuiltepetl ',NULL,'G','91097',30,2291,'Rodríguez'),('s15011669','Miguel Alejandro','Cámara','M','1994-12-21',NULL,'arcamsoft@gmail.com','zS15011669@estudiantes.uv.mx','2281595710','@alexarcam','Alex Cámara','Altiplano 19, Valles de cristal',NULL,'19','91159',6,187,'Árciga'),('S15011674','Cristhian','Ubaldo','M','1997-04-16',NULL,'zs15011674@estudiantes.uv.mx','zS15011674@estudiantes.uv.mx','2282813871','','','Calle José Arrillaga',NULL,'45','91060',9,267,'Promotor'),('S15013598','JESUS ANTONIO','ROSAS','M','1997-06-30',NULL,'licrscjarp@gmail.com','zs15013598@estudiantes.uv.mx','2282933041','','','CARRETERA NACIONAL',NULL,'21 A','91635',30,2099,'PERCASTRE'),('S15022810','Mariana','Cadena','F','1997-06-18','Soltero/a','marhcr18@gmail.com','zS14000000@estudiantes.uv.mx',NULL,'Marianacro_','Mariana Cadena','Priv. Rafael Ramirez No 5 Col. Centro',NULL,'5','91000',30,2291,'Romero'),('s15022811','Jesús Eduardo','Hernández','M','1997-07-09',NULL,'Jesus_hdezmtz@hotmail.com','zs15022811@estudiantes.uv.mx','2281132016','@JesusHdezMtz10','Jesús Hdez Mtz','Primera de Francisco Javier Mina, Centro',NULL,'25','91500',30,2139,'Martínez'),('S190001','Marianita','Cadena','F','1999-06-18','Soltero/a','marhcr18@gmail.com','correo@uv.mx',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Palmeros'),('s23456789','Alberto','Hernández','M','1995-10-08',NULL,'juan@hotmail.com','zS14000000@estudiantes.uv.mx','','','','Lorenzo de zavala',NULL,'40','91100',30,2291,'Gómez');
/*!40000 ALTER TABLE `alumno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add alumno',7,'add_alumno'),(26,'Can change alumno',7,'change_alumno'),(27,'Can delete alumno',7,'delete_alumno'),(28,'Can view alumno',7,'view_alumno'),(29,'Can add continuacion_estudios',8,'add_continuacion_estudios'),(30,'Can change continuacion_estudios',8,'change_continuacion_estudios'),(31,'Can delete continuacion_estudios',8,'delete_continuacion_estudios'),(32,'Can view continuacion_estudios',8,'view_continuacion_estudios'),(33,'Can add desempenio_recomendaciones',9,'add_desempenio_recomendaciones'),(34,'Can change desempenio_recomendaciones',9,'change_desempenio_recomendaciones'),(35,'Can delete desempenio_recomendaciones',9,'delete_desempenio_recomendaciones'),(36,'Can view desempenio_recomendaciones',9,'view_desempenio_recomendaciones'),(37,'Can add empleo_inmediato',10,'add_empleo_inmediato'),(38,'Can change empleo_inmediato',10,'change_empleo_inmediato'),(39,'Can delete empleo_inmediato',10,'delete_empleo_inmediato'),(40,'Can view empleo_inmediato',10,'view_empleo_inmediato'),(41,'Can add empresa',11,'add_empresa'),(42,'Can change empresa',11,'change_empresa'),(43,'Can delete empresa',11,'delete_empresa'),(44,'Can view empresa',11,'view_empresa'),(45,'Can add estados',12,'add_estados'),(46,'Can change estados',12,'change_estados'),(47,'Can delete estados',12,'delete_estados'),(48,'Can view estados',12,'view_estados'),(49,'Can add licenciatura',13,'add_licenciatura'),(50,'Can change licenciatura',13,'change_licenciatura'),(51,'Can delete licenciatura',13,'delete_licenciatura'),(52,'Can view licenciatura',13,'view_licenciatura'),(53,'Can add municipios',14,'add_municipios'),(54,'Can change municipios',14,'change_municipios'),(55,'Can delete municipios',14,'delete_municipios'),(56,'Can view municipios',14,'view_municipios'),(57,'Can add seleccion_carrera',15,'add_seleccion_carrera'),(58,'Can change seleccion_carrera',15,'change_seleccion_carrera'),(59,'Can delete seleccion_carrera',15,'delete_seleccion_carrera'),(60,'Can view seleccion_carrera',15,'view_seleccion_carrera');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$180000$O1ypKceR9uSL$/uvXoPW7dmltNUttRbIe7ajovwAgTiq0qTBDF+S/LUI=',NULL,1,'marianacro','','','marhcr18@gmail.com',1,1,'2020-03-03 16:45:50.705043');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `continuacion_estudios`
--

DROP TABLE IF EXISTS `continuacion_estudios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `continuacion_estudios` (
  `id_continuacion_estudios` int NOT NULL AUTO_INCREMENT,
  `tipoestudio_continuacion` varchar(45) DEFAULT NULL,
  `institucion` varchar(45) DEFAULT NULL,
  `nombre_programa` varchar(45) DEFAULT NULL,
  `anio_inicio` varchar(45) DEFAULT NULL,
  `anio_fin` varchar(45) DEFAULT NULL,
  `matricula` varchar(10) NOT NULL,
  PRIMARY KEY (`id_continuacion_estudios`),
  KEY `fk_continuacionEstudios_alumno1` (`matricula`),
  CONSTRAINT `fk_continuacionEstudios_alumno1` FOREIGN KEY (`matricula`) REFERENCES `alumno` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `continuacion_estudios`
--

LOCK TABLES `continuacion_estudios` WRITE;
/*!40000 ALTER TABLE `continuacion_estudios` DISABLE KEYS */;
/*!40000 ALTER TABLE `continuacion_estudios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `desempenio_recomendaciones`
--

DROP TABLE IF EXISTS `desempenio_recomendaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `desempenio_recomendaciones` (
  `id_desempenio_recomendaciones` int NOT NULL AUTO_INCREMENT,
  `nivel_satisfaccion` varchar(45) DEFAULT NULL,
  `grado_exigencia` varchar(45) DEFAULT NULL,
  `nivel_formacion` varchar(45) DEFAULT NULL,
  `modificaciones_planest` varchar(45) DEFAULT NULL,
  `opinion_orgainst` varchar(45) DEFAULT NULL,
  `matricula` varchar(10) NOT NULL,
  PRIMARY KEY (`id_desempenio_recomendaciones`),
  KEY `fk_desempeñoRecomendaciones_alumno1` (`matricula`),
  CONSTRAINT `fk_desempeñoRecomendaciones_alumno1` FOREIGN KEY (`matricula`) REFERENCES `alumno` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `desempenio_recomendaciones`
--

LOCK TABLES `desempenio_recomendaciones` WRITE;
/*!40000 ALTER TABLE `desempenio_recomendaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `desempenio_recomendaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(7,'controlEgresados','alumno'),(8,'controlEgresados','continuacion_estudios'),(9,'controlEgresados','desempenio_recomendaciones'),(10,'controlEgresados','empleo_inmediato'),(11,'controlEgresados','empresa'),(12,'controlEgresados','estados'),(13,'controlEgresados','licenciatura'),(14,'controlEgresados','municipios'),(15,'controlEgresados','seleccion_carrera'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2020-03-03 16:45:21.316794'),(2,'auth','0001_initial','2020-03-03 16:45:21.496743'),(3,'admin','0001_initial','2020-03-03 16:45:21.875565'),(4,'admin','0002_logentry_remove_auto_add','2020-03-03 16:45:21.973366'),(5,'admin','0003_logentry_add_action_flag_choices','2020-03-03 16:45:21.987194'),(6,'contenttypes','0002_remove_content_type_name','2020-03-03 16:45:22.077841'),(7,'auth','0002_alter_permission_name_max_length','2020-03-03 16:45:22.134136'),(8,'auth','0003_alter_user_email_max_length','2020-03-03 16:45:22.198082'),(9,'auth','0004_alter_user_username_opts','2020-03-03 16:45:22.211911'),(10,'auth','0005_alter_user_last_login_null','2020-03-03 16:45:22.259418'),(11,'auth','0006_require_contenttypes_0002','2020-03-03 16:45:22.263357'),(12,'auth','0007_alter_validators_add_error_messages','2020-03-03 16:45:22.277294'),(13,'auth','0008_alter_user_username_max_length','2020-03-03 16:45:22.340608'),(14,'auth','0009_alter_user_last_name_max_length','2020-03-03 16:45:22.396876'),(15,'auth','0010_alter_group_name_max_length','2020-03-03 16:45:22.462170'),(16,'auth','0011_update_proxy_permissions','2020-03-03 16:45:22.477643'),(17,'controlEgresados','0001_initial','2020-03-03 16:45:22.498416'),(18,'sessions','0001_initial','2020-03-03 16:45:22.522567');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('huujzodmoq9zzcgqag2i0300gahuplz0','YzI2MDc0NzE0NGQ2MTNiMDUyYmQ1Mjg2NzVlZGEyNmU0YTViYjZkYjp7Im1hdHJpY3VsYSI6IlMxNTAyMjgxMCJ9','2020-08-01 00:56:55.707257');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empleo_inmediato`
--

DROP TABLE IF EXISTS `empleo_inmediato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleo_inmediato` (
  `id_empleo_inmediato` int NOT NULL AUTO_INCREMENT,
  `trabajo_ultimoanio` varchar(45) DEFAULT NULL,
  `coincidencia_trabajoest` varchar(45) DEFAULT NULL,
  `horas_lab_semanales` varchar(45) DEFAULT NULL,
  `trabajo_finlic` varchar(45) DEFAULT NULL,
  `busqueda_trab_finlic` varchar(45) DEFAULT NULL,
  `tiempo_primerempleo` varchar(45) DEFAULT NULL,
  `razon_dificultad_primerempleo` varchar(45) DEFAULT NULL,
  `medio_conseguir_empleo` varchar(45) DEFAULT NULL,
  `requisito_formal_empleo` varchar(45) DEFAULT NULL,
  `puesto_empleo_inmediato` varchar(45) DEFAULT NULL,
  `tamano_empresa_inmediata` varchar(45) DEFAULT NULL,
  `regimen_juridico` varchar(45) DEFAULT NULL,
  `ingreso_mensual_neto_Inicio` varchar(45) DEFAULT NULL,
  `anio` varchar(45) DEFAULT NULL,
  `horas_laboral_semanales` varchar(45) DEFAULT NULL,
  `duracion_trabajo` varchar(45) DEFAULT NULL,
  `sector_economico` varchar(45) DEFAULT NULL,
  `razon_nobusqueda_empleo` varchar(45) DEFAULT NULL,
  `matricula` varchar(10) NOT NULL,
  PRIMARY KEY (`id_empleo_inmediato`),
  KEY `fk_empleoInmediato_alumno1` (`matricula`),
  CONSTRAINT `fk_empleoInmediato_alumno1` FOREIGN KEY (`matricula`) REFERENCES `alumno` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleo_inmediato`
--

LOCK TABLES `empleo_inmediato` WRITE;
/*!40000 ALTER TABLE `empleo_inmediato` DISABLE KEYS */;
/*!40000 ALTER TABLE `empleo_inmediato` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empresa` (
  `id_empresa` int NOT NULL AUTO_INCREMENT,
  `nombre_empresa` varchar(45) DEFAULT NULL,
  `calle_empresa` varchar(45) DEFAULT NULL,
  `colonia_empresa` varchar(45) DEFAULT NULL,
  `num_empresa` varchar(45) DEFAULT NULL,
  `codigo_postal` varchar(45) DEFAULT NULL,
  `departamento` varchar(45) DEFAULT NULL,
  `id_estado` int DEFAULT NULL,
  `id_municipio` int DEFAULT NULL,
  `puesto` varchar(45) DEFAULT NULL,
  `tipo_contratacion` varchar(45) DEFAULT NULL,
  `regimen_juridico` varchar(45) DEFAULT NULL,
  `ingresomensual_neto` varchar(45) DEFAULT NULL,
  `horas_laborales` varchar(45) DEFAULT NULL,
  `fecha_inicio` varchar(45) DEFAULT NULL,
  `medida_coincidencia_labestudios` varchar(45) DEFAULT NULL,
  `sector_economico` varchar(45) DEFAULT NULL,
  `otro_empleo` varchar(45) DEFAULT NULL,
  `matricula` varchar(10) NOT NULL,
  PRIMARY KEY (`id_empresa`),
  KEY `fk_empresa_estados1` (`id_estado`),
  KEY `fk_empresa_municipios1` (`id_municipio`),
  KEY `fk_empresa_alumno1` (`matricula`),
  CONSTRAINT `fk_empresa_alumno1` FOREIGN KEY (`matricula`) REFERENCES `alumno` (`matricula`),
  CONSTRAINT `fk_empresa_estados1` FOREIGN KEY (`id_estado`) REFERENCES `estados` (`id_estado`),
  CONSTRAINT `fk_empresa_municipios1` FOREIGN KEY (`id_municipio`) REFERENCES `municipios` (`id_municipio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estados`
--

DROP TABLE IF EXISTS `estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estados` (
  `id_estado` int NOT NULL AUTO_INCREMENT,
  `estado` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_estado`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estados`
--

LOCK TABLES `estados` WRITE;
/*!40000 ALTER TABLE `estados` DISABLE KEYS */;
INSERT INTO `estados` VALUES (1,'AGUASCALIENTES'),(2,'BAJA CALIFORNIA'),(3,'BAJA CALIFORNIA SUR'),(4,'CAMPECHE'),(5,'CHIAPAS'),(6,'CHIHUAHUA'),(7,'COAHUILA'),(8,'COLIMA'),(9,'DISTRITO FEDERAL'),(10,'DURANGO'),(11,'ESTADO DE MÉXICO'),(12,'GUANAJUATO'),(13,'GUERRERO'),(14,'HIDALGO'),(15,'JALISCO'),(16,'MICHOACÁN'),(17,'MORELOS'),(18,'NAYARIT'),(19,'NUEVO LEÓN'),(20,'OAXACA'),(21,'PUEBLA'),(22,'QUERÉTARO'),(23,'QUINTANA ROO'),(24,'SAN LUIS POTOSÍ'),(25,'SINALOA'),(26,'SONORA'),(27,'TABASCO'),(28,'TAMAULIPAS'),(29,'TLAXCALA'),(30,'VERACRUZ'),(31,'YUCATÁN'),(32,'ZACATECAS');
/*!40000 ALTER TABLE `estados` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `licenciatura`
--

DROP TABLE IF EXISTS `licenciatura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `licenciatura` (
  `id_licenciatura` int NOT NULL AUTO_INCREMENT,
  `nombre_campus` varchar(45) NOT NULL,
  `nombre_carrera` varchar(45) NOT NULL,
  `anio_pestudios` varchar(45) DEFAULT NULL,
  `anio_inicio` varchar(25) DEFAULT NULL,
  `anio_fin` varchar(25) DEFAULT NULL,
  `org_ss` varchar(45) DEFAULT NULL,
  `fecha_inicioss` date DEFAULT NULL,
  `fecha_finss` date DEFAULT NULL,
  `titulado` varchar(10) DEFAULT NULL,
  `promedio_final` varchar(10) DEFAULT NULL,
  `tipo_inscripcion` varchar(25) DEFAULT NULL,
  `matricula` varchar(10) NOT NULL,
  PRIMARY KEY (`id_licenciatura`),
  KEY `fk_licenciatura_alumno1` (`matricula`),
  CONSTRAINT `fk_licenciatura_alumno1` FOREIGN KEY (`matricula`) REFERENCES `alumno` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `licenciatura`
--

LOCK TABLES `licenciatura` WRITE;
/*!40000 ALTER TABLE `licenciatura` DISABLE KEYS */;
/*!40000 ALTER TABLE `licenciatura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `municipios`
--

DROP TABLE IF EXISTS `municipios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `municipios` (
  `id_municipio` int NOT NULL AUTO_INCREMENT,
  `nombre_municipio` varchar(100) NOT NULL,
  `id_estado` int NOT NULL,
  PRIMARY KEY (`id_municipio`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2466 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `municipios`
--

LOCK TABLES `municipios` WRITE;
/*!40000 ALTER TABLE `municipios` DISABLE KEYS */;
INSERT INTO `municipios` VALUES (1,'AGUASCALIENTES',1),(2,'ASIENTOS',1),(3,'CALVILLO',1),(4,'COSÍO',1),(5,'JESÚS MARIA',1),(6,'PABELLÓN DE ARTEAGA',1),(7,'RINCÓN DE ROMOS',1),(8,'SAN JOSÉ DE GRACIA',1),(9,'TEPEZALÁ',1),(10,'SAN FRANCISCO DE LOS ROMO',1),(11,'EL LLANO',1),(12,'ENSENADA',2),(13,'MEXICALI',2),(14,'TECATE',2),(15,'TIJUANA',2),(16,'PLAYAS DE ROSARITO',2),(17,'COMONDÚ',3),(18,'MULEGÉ',3),(19,'LA PAZ',3),(20,'LOS CABOS',3),(21,'LORETO',3),(22,'CALKINÍ',4),(23,'CAMPECHE',4),(24,'CARMEN',4),(25,'CHAMPOTÓN',4),(26,'HECELCHAKÁN',4),(27,'HOPELCHÉN',4),(28,'PALIZADA',4),(29,'TENABO',4),(30,'ESCÁRCEGA',4),(31,'CALAKMUL',4),(32,'CANDELARIA',4),(33,'ACACOYAGUA ',5),(34,'ACALA ',5),(35,'ACAPETAHUA ',5),(36,'ALDAMA ',5),(37,'ALTAMIRANO ',5),(38,'AMATÁN',5),(39,'AMATENANGO DE LA FRONTERA ',5),(40,'AMATENANGO DEL VALLE ',5),(41,'ANGEL ALBINO CORZO ',5),(42,'ARRIAGA ',5),(43,'BEJUCAL DE OCAMPO ',5),(44,'BELLA VISTA ',5),(45,'BENEMÉRITO DE LAS AMÉRICAS ',5),(46,'BERRIOZÁBAL ',5),(47,'BOCHIL ',5),(48,'EL BOSQUE RN',5),(49,'CACAHOATÁN ',5),(50,'CATAZAJÁ ',5),(51,'CINTALAPA ',5),(52,'COAPILLA ',5),(53,'COMITÁN DE DOMÍNGUEZ ',5),(54,'LA CONCORDIA ',5),(55,'COPAINALÁ ',5),(56,'CHALCHIHUITÁN ',5),(57,'CHAMULA ',5),(58,'CHANAL ',5),(59,'CHAPULTENANGO ',5),(60,'CHENALHÓ ',5),(61,'CHIAPA DE CORZO ',5),(62,'CHIAPILLA ',5),(63,'CHICOASÉN ',5),(64,'CHICOMUSELO ',5),(65,'CHILÓN ',5),(66,'ESCUINTLA ',5),(67,'FRANCISCO LEÓN ',5),(68,'FRONTERA COMALAPA ',5),(69,'FRONTERA HIDALGO ',5),(70,'LA GRANDEZA ',5),(71,'HUHUETÁN ',5),(72,'HUIXTÁN ',5),(73,'HUITIUPÁN ',5),(74,'HUIXTLA ',5),(75,'LA INDEPENDENCIA ',5),(76,'IXHUATÁN ',5),(77,'IXTACOMITÁN ',5),(78,'IXTAPA ',5),(79,'IXTAPANGAJOYA',5),(80,'JIQUIPILAS',5),(81,' JITOTOL',5),(82,'JUÁREZ ',5),(83,'LARRÁINZAR ',5),(84,'LA LIBERTAD ',5),(85,'MAPASTEPEC ',5),(86,'MARAVILLA TENEJAPA ',5),(87,'MARQUÉS DE COMILLAS ',5),(88,'MAZAPA DE MADERO ',5),(89,'MAZATÁN ',5),(90,'METAPA ',5),(91,'MITONTIC ',5),(92,'MONTECRISTO DE GUERRERO ',5),(93,'MOTOZINTLA ',5),(94,'NICOLÁS RUÍZ ',5),(95,'OCOSINGO RN',5),(96,'OCOTEPEC ',5),(97,'OCOZOCOAUTLA DE ESPINOSA ',5),(98,'OSTUACÁN ',5),(99,'OSUMACINTA ',5),(100,'OXCHUC ',5),(101,'PALENQUE ',5),(102,'PANTELHÓ ',5),(103,'PANTEPEC ',5),(104,'PICHUCALCO ',5),(105,'PIJIJIAPAN ',5),(106,'EL PORVENIR ',5),(107,'PUEBLO NUEVO SOLISTAHUACÁN ',5),(108,'RAYÓN ',5),(109,'REFORMA ',5),(110,'LAS ROSAS ',5),(111,'LAS ROSAS ',5),(112,'SABANILLA ',5),(113,'SALTO DE AGUA ',5),(114,'SAN ANDRÉS DURAZNAL ',5),(115,'SAN CRISTOBAL DE LAS CASAS ',5),(116,'SAN FERNANDO ',5),(117,'SAN JUAN CANCUC ',5),(118,'SAN LUCAS ',5),(119,'SANTIAGO EL PINAR ',5),(120,'SILTEPEC ',5),(121,'SIMOJOVEL ',5),(122,'SITALÁ ',5),(123,'SOCOLTENANGO ',5),(124,'SOLOSUCHIAPA ',5),(125,'SOYALÓ ',5),(126,'SUCHIAPA ',5),(127,'SUCHIATE ',5),(128,'SUNUAPA ',5),(129,'TAPACHULA ',5),(130,'TAPALAPA ',5),(131,'TAPILULA ',5),(132,'TECPATÁN ',5),(133,'TENEJAPA ',5),(134,'TEOPISCA ',5),(135,'TILA ',5),(136,'TONALÁ ',5),(137,'TOTOLAPA ',5),(138,'LA TRINITARIA ',5),(139,'TUMBALÁ ',5),(140,'TUXTLA GUTIÉRREZ ',5),(141,'TUXTLA CHICO ',5),(142,'TUZANTÁN ',5),(143,'TZIMOL ',5),(144,'UNIÓN JUÁREZ ',5),(145,'VENUSTIANO CARRANZA ',5),(146,'VILLA COMALTITLÁN ',5),(147,'VILLA CORZO ',5),(148,'VILLAFLORES ',5),(149,'YAJALÓN ',5),(150,'ZINACANTÁN ',5),(151,'AHUMADA',6),(152,'ALDAMA',6),(153,'ALLENDE',6),(154,'AQUILES SERDÁNSERDÁN',6),(155,'ASCENSIÓN',6),(156,'BACHÍNIVA',6),(157,'BALLEZA',6),(158,'BATOPILAS',6),(159,'BOCOYNA',6),(160,'BUENAVENTURA',66),(161,'CAMARGO',6),(162,'CARICHI',6),(163,'CASAS GRANDES',6),(164,'CORONADO',6),(165,'COYAME DEL SOTOL',6),(166,'LA CRUZ',6),(167,'CUAUHTÉMOC',6),(168,'CUSIHUIRIÁCHI',6),(169,'CHIHUAHUA',6),(170,'CHÍNIPAS',6),(171,'DELICIAS',6),(172,'DR. BELISARIO DOMÍNGUEZ',6),(173,'GALEANA',6),(174,'SANTA ISABEL',6),(175,'GÓMEZ FARÍAS',6),(176,'GRAN MORELOS',6),(177,'GUACHOCHI',6),(178,'GUADALUPE D.B.',6),(179,'GUADALUPE Y CALVO',6),(180,'GUAZAPARES',6),(181,'GUERRERO',6),(182,'HIDALGO DEL PARRAL',6),(183,'HUEJOTITÁN',6),(184,'IGNACIO ZARAGOZA',6),(185,'JANOS',6),(186,'JIMÉNEZ',6),(187,'JUÁREZ',6),(188,'JULIMES',6),(189,'LÓPEZ',6),(190,'MADERA',6),(191,'MAGUARICHI',6),(192,'MANUEL BENAVIDES',6),(193,'MATACHI',6),(194,'MATAMOROS',6),(195,'MEOQUI',6),(196,'MORELOS',6),(197,'MORIS',6),(198,'NAMIQUIPA',6),(199,'NONOAVA',6),(200,'NUEVO CASAS GRANDES',6),(201,'OCAMPO',6),(202,'OJINAGA',6),(203,'PRAXEDIS G. GUERRERO',6),(204,'RIVA PALACIO',6),(205,'ROSALES',6),(206,'ROSARIO',6),(207,'SAN FRANCISCO DE BORJA',6),(208,'SAN FRANCISCO DE CONCHOS',6),(209,'SAN FRANCISCO DEL ORO',6),(210,'SANTA BÁRBARA',6),(211,'SATEVÓ',6),(212,'SAUCILLO',6),(213,'TEMÓSACHI',6),(214,'EL TULE',6),(215,'URIQUE',6),(216,'URUÁCHI',6),(217,'VALLE DE ZARAGOZA',6),(218,'ABASOLO',7),(219,'ACUÑA',7),(220,'ALLENDE',7),(221,'ARTEAGA',7),(222,'CANDELA',7),(223,'CASTAÑOS',7),(224,'CUATROCIENEGAS',7),(225,'ESCOBEDO',7),(226,'FRANCISCO I. MADERO',7),(227,'FRONTERA',7),(228,'GENERAL CEPEDA',7),(229,'GUERRERO',7),(230,'HIDALGO',7),(231,'JIMENEZ',7),(232,'JUAREZ',7),(233,'LAMADRID',7),(234,'MATAMOROS',7),(235,'MONCLOVA',7),(236,'MORELOS',7),(237,'MUZQUIZ',7),(238,'NADADORES',7),(239,'NAVA',7),(240,'OCAMPO',7),(241,'PARRAS',7),(242,'PIEDRAS NEGRAS',7),(243,'PROGRESO',7),(244,'RAMOS ARIZPE',7),(245,'SABINAS',7),(246,'SACRAMENTO',7),(247,'SALTILLO',7),(248,'SAN BUENAVENTURA',7),(249,'SAN JUAN DE SABINAS',7),(250,'SAN PEDRO',7),(251,'SIERRA MOJADA',7),(252,'TORREON',7),(253,'VIESCA',7),(254,' VILLA UNION',7),(255,' ZARAGOZA',7),(256,'ARMERÍA',8),(257,'COLIMA',8),(258,'COMALA',8),(259,'COQUIMATLÁN',8),(260,'CUAUHTÉMOC',8),(261,'IXTLAHUACÁN',8),(262,'MANZANILLO',8),(263,'MINATITLÁN',8),(264,'TECOMÁN',8),(265,'VILLA DE ÁLVAREZ',8),(266,'ALVARO OBREGÓN',9),(267,'AZCAPOTZALCO',9),(268,'BENITO JUAREZ',9),(269,'COYOACAN',9),(270,'CUAJIMALPA DE MORELOS',9),(271,'CUAUHTEMOC',9),(272,'GUSTAVO A. MADERO',9),(273,'IZTACALCO',9),(274,'IZTAPALAPA',9),(275,'LA MAGDALENA CONTRERAS',9),(276,'MIGUEL HIDALGO',9),(277,'MILPA ALTA',9),(278,'TLAHUAC',9),(279,'TLALPAN',9),(280,'VENUSTIANO CARRANZA',9),(281,'XOCHIMILCO',9),(282,'CANATLÁN',10),(283,'CANELAS',10),(284,'CONETO DE COMONFORT',10),(285,'CUENCAMÉ',10),(286,'DURANGO',10),(287,'GENERAL SIMÓN BOLÍVAR',10),(288,'GÓMEZ PALACIO',10),(289,'GUADALUPE VICTORIA',10),(290,'GUANACEVÍ',10),(291,'HIDALGO',10),(292,'INDÉ',10),(293,'CIUDAD LERDO',10),(294,'MAPIMÍ',10),(295,'MEZQUITAL',10),(296,'NAZAS',10),(297,'NOMBRE DE DIOS',10),(298,'OCAMPO',10),(299,'EL ORO',10),(300,'OTÁEZ',10),(301,'PÁNUCO DE CORONADO',10),(302,'PEÑÓN BLANCO',10),(303,'POANAS',10),(304,'PUEBLO NUEVO',10),(305,'RODEO',10),(306,'SAN BERNARDO',10),(307,'SAN DIMAS',10),(308,'SAN JUAN DE GUADALUPE',10),(309,'SAN JUAN DEL RÍO',10),(310,'SAN LUIS DEL CORDERO',10),(311,'SAN PEDRO DEL GALLO',10),(312,'SANTIAGO PAPASQUIARO',10),(313,'SÚCHIL',10),(314,'TAMAZULA',10),(315,'TEPEHUANES',10),(316,'TLAHUALILO',10),(317,'TOPIA',10),(318,'VICENTE GUERRERO',10),(319,'NUEVO IDEAL',10),(320,'ACAMBAY',11),(321,'ACOLMAN',11),(322,'ACULCO',11),(323,'ALMOLOYA DE ALQUISIRAS',11),(324,'ALMOLOYA DE  JUÁREZ',11),(325,'ALMOLOYA DEL RÍO',11),(326,'AMANALCO',11),(327,'AMATEPEC',11),(328,'AMECAMECA',11),(329,'APAXCO',11),(330,'ATENCO',11),(331,'ATIZAPÁN',11),(332,'ATIZAPÁN DE ZARAGOZA',11),(333,'ATLACOMULCO',11),(334,'ATLAUTLA',11),(335,'AXAPUSCO',11),(336,'AYAPANGO',11),(337,'CALIMAYA',11),(338,'CAPULHUAC',11),(339,'COACALCO DE BERRIOZÁBAL',11),(340,'COATEPEC HARINAS',11),(341,'COCOTITLÁN',11),(342,'COYOTEPEC',11),(343,'CUAUTITLÁN',11),(344,'CHALCO',11),(345,'CHAPA DE MOTA',11),(346,'CHAPULTEPEC',11),(347,'CHIAUTLA',11),(348,'CHICOLOAPAN',11),(349,'CHICONCUAC',11),(350,'CHIMALHUACÁN',11),(351,'DONATO GUERRA',11),(352,'ECATEPEC',11),(353,'ECATZINGO',11),(354,'HUEHUETOCA',11),(355,'HUEYPOXTLA',11),(356,'HUIXQUILUCAN',11),(357,'ISIDRO FABELA',11),(358,'IXTAPALUCA',11),(359,'IXTAPAN DE LA SAL',11),(360,'IXTAPAN DEL ORO',11),(361,'IXTLAHUACA',11),(362,'XALATLACO',11),(363,'JALTENCO',11),(364,'JILOTEPEC',11),(365,'JILOTZINGO',11),(366,'JIQUIPILCO',11),(367,'JOCOTITLÁN',11),(368,'JOQUICINGO',11),(369,'JUCHITEPEC',11),(370,'LERMA',11),(371,'MALINALCO',11),(372,'MELCHOR OCAMPO',11),(373,'METEPEC',11),(374,'MEXICALTZINGO',11),(375,'MORELOS',11),(376,'NAUCALPAN DE JUÁREZ',11),(377,'NEZAHUALCÓYOTL',11),(378,'NEXTLALPAN',11),(379,'NICOLÁS ROMERO',11),(380,'NOPALTEPEC',11),(381,'OCOYOACAC',11),(382,'OCUILAN',11),(383,'EL ORO',11),(384,'OTUMBA',11),(385,'OTZOLOAPAN',11),(386,'OTZOLOTEPEC',11),(387,'OZUMBA',11),(388,'PAPALOTLA',11),(389,'LA PAZ',11),(390,'POLOTITLÁN',11),(391,'RAYÓN',11),(392,'SAN ANTONIO LA ISLA',11),(393,'SAN FELIPE DEL PROGRESO',11),(394,'SAN MARTÍN DE LAS PIRÁMIDES',11),(395,'SAN MATEO ATENCO',11),(396,'SAN SIMÓN DE GUERRERO',11),(397,'SANTO TOMÁS',11),(398,'SOYANIQUILPAN DE JUÁREZ',11),(399,'SULTEPEC',11),(400,'TECÁMAC',11),(401,'TEJUPILCO',11),(402,'TEMAMATLA',11),(403,'TEMASCALAPA',11),(404,'TEMASCALCINGO',11),(405,'TEMASCALTEPEC',11),(406,'TEMOAYA',11),(407,'TENANCINGO',11),(408,'TENANGO DEL AIRE',11),(409,'TENANGO DEL VALLE',11),(410,'TEOLOYUCAN',11),(411,'TEOTIHUACÁN',11),(412,'TEPETLAOXTOC',11),(413,'TEPETLIXPA',11),(414,'TEPOTZOTLÁN',11),(415,'TEQUIXQUIAC',11),(416,'TEXCALTITLÁN',11),(417,'TEXCALYACAC',11),(418,'TEXCOCO',11),(419,'TEZOYUCA',11),(420,'TIANGUISTENCO',11),(421,'TIMILPAN',11),(422,'TLALMANALCO',11),(423,'TLALNEPANTLA DE BAZ',11),(424,'TLATLAYA',11),(425,'TOLUCA',11),(426,'TONATICO',11),(427,'TULTEPEC',11),(428,'TULTITLÁN',11),(429,'VALLE DE BRAVO',11),(430,'VILLA DE ALLENDE',11),(431,'VILLA DEL CARBÓN',11),(432,'VILLA GUERRERO',11),(433,'VILLA VICTORIA',11),(434,'XONACATLÁN',11),(435,'ZACAZONAPAN',11),(436,'ZACUALPAN',11),(437,'ZINACANTEPEC',11),(438,'ZUMPAHUACÁN',11),(439,'ZUMPANGO',11),(440,'CUAUTITLÁN IZCALLI',11),(441,'VALLE DE CHALCO SOLIDARIDAD',11),(442,'LUVIANOS',11),(443,'SAN JOSÉ DEL RINCÓN',11),(444,'SANTA MARÍA TONANITLA',11),(445,'ABASOLO',12),(446,'ACAMBARO',12),(447,'ALLENDE',12),(448,'APASEO EL ALTO',12),(449,'APASEO EL GRANDE',12),(450,'ATARJEA',12),(451,'CELAYA',12),(452,'MANUEL DOBLADO',12),(453,'COMONFORT',12),(454,'CORONEO',12),(455,'CORTAZAR',12),(456,'CUERAMARO',12),(457,'DOCTOR MORA',12),(458,'DOLORES HIDALGO',12),(459,'GUANAJUATO',12),(460,'HUANIMARO',12),(461,'IRAPUATO',12),(462,'JARAL DEL PROGRESO',12),(463,'JERECUARO',12),(464,'LEON',12),(465,'MOROLEON',12),(466,'OCAMPO',12),(467,'PENJAMO',12),(468,'PUEBLO NUEVO',12),(469,'PURISIMA DEL RINCON',12),(470,'ROMITA',12),(471,'SALAMANCA',12),(472,'SALVATIERRA',12),(473,'SAN DIEGO DE LA UNION',12),(474,'SAN FELIPE',12),(475,'SAN FRANCISCO DEL RINCON',12),(476,'SAN JOSE ITURBIDE',12),(477,'SAN LUIS DE LA PAZ',12),(478,'SANTA CATARINA',12),(479,'SANTA CRUZ DE JUVENTINO ROSAS',12),(480,'SANTIAGO MARAVATIO',12),(481,'SILAO',12),(482,'TARANDACUAO',12),(483,'TARIMORO',12),(484,'TIERRA BLANCA',12),(485,'URIANGATO',12),(486,'VALLE DE SANTIAGO',12),(487,'VICTORIA',12),(488,'VILLAGRAN',12),(489,'XICHU',12),(490,'YURIRIA',12),(491,'ACAPULCO DE JUÁREZ  ',13),(492,'ACATEPEC ',13),(493,'AHUACUOTZINGO ',13),(494,'AJUCHITLAN DEL PROGRESO ',13),(495,'ALCOZAUCA DE GUERRERO ',13),(496,'ALPOYECA ',13),(497,'APAXTLA ',13),(498,'ARCELIA ',13),(499,'ATENANGO DEL RÍO ',13),(500,'ATLAMAJALCINGO DEL MONTE ',13),(501,'ATLIXTAC ',13),(502,'ATOYAC DE ÁLVAREZ ',13),(503,'AYUTLA ',13),(504,'AZOYÚ ',13),(505,'BENITO JUÁREZ ',13),(506,'BUENAVISTA DE CUÉLLAR ',13),(507,'CHILAPA DE ÁLVAREZ ',13),(508,'CHILPANCINGO DE LOS BRAVO ',13),(509,'COAHUAYUTLA DE JOSÉ MARÍA IZAZAGA ',13),(510,'COCHOAPA EL GRANDE',13),(511,'COCULA ',13),(512,'COPALA ',13),(513,'COPALILLO ',13),(514,'COPANATOYAC  ',13),(515,'COYUCA DE BENÍTEZ ',13),(516,'COYUCA DE CATALÁN ',13),(517,'CUAJINICUILAPA ',13),(518,'CUALÁC ',13),(519,'CUAUTEPEC ',13),(520,'CUETZALA DEL PROGRESO ',13),(521,'CUTZAMALA DE PINZÓN ',13),(522,'EDUARDO NERI ',13),(523,'FLORENCIO VILLARREAL ',13),(524,'GENERAL CANUTO A. NERI ',13),(525,'GENERAL HELIODORO CASTILLO ',13),(526,'HUAMUXTITLÁN ',13),(527,'HUITZUCO DE LOS FIGUEROA ',13),(528,'IGUALA ',13),(529,'IGUALAPA ',13),(530,'ILIATENCO',13),(531,'IXCATEOPAN DE CUAUHTÉMOC ',13),(532,'JOSÉ JOAQUÍN DE HERRERA',13),(533,'JUAN R. ESCUDERO  ',13),(534,'JUCHITÁN',13),(535,'LA UNIÓN ',13),(536,'LEONARDO BRAVO ',13),(537,'MALINALTEPEC ',13),(538,'MARQUELIA',13),(539,'MÁRTIR DE CUILAPAN ',13),(540,'METLATÓNOC ',13),(541,'MOCHITLÁN ',13),(542,'OLINALÁ ',13),(543,'OMETEPEC ',13),(544,'PEDRO ASCENCIO ALQUISIRAS ',13),(545,'PETATLÁN ',13),(546,'PILCAYA ',13),(547,'PUNGARABATO ',13),(548,'QUECHULTENANGO ',13),(549,'SAN LUIS ACATLÁN ',13),(550,'SAN MARCOS ',13),(551,'SAN MIGUEL TOTOLAPAN ',13),(552,'TAXCO DE ALARCÓN ',13),(553,'TECOANAPA ',13),(554,'TECPAN DE GALEANA ',13),(555,'TELOLOAPAN  ',13),(556,'TENIENTE JOSÉ AZUETA ',13),(557,'TEPECOACUILCO DE TRUJANO ',13),(558,'TETIPAC ',13),(559,'TIXTLA DE GUERRERO ',13),(560,'TLACOACHISTLAHUACA ',13),(561,'TLACOAPA ',13),(562,'TLALCHAPA ',13),(563,'TLALIXTAQUILLA ',13),(564,'TLAPA DE COMONFORT ',13),(565,'TLAPEHUALA ',13),(566,'XALPATLÁHUAC ',13),(567,'XOCHIHUEHUETLÁN ',13),(568,'XOCHISTLAHUACA ',13),(569,'ZAPOTITLÁN TABLAS ',13),(570,'ZIRÁNDARO DE LOS CHÁVEZ ',13),(571,'ZITLALA ',13),(572,'ACATLAN',14),(573,'HUICHAPAN',14),(574,'SINGUILUCAN',14),(575,'ACAXOCHITLAN',14),(576,'IXMIQUILPAN',14),(577,'TASQUILLO',14),(578,'ACTOPAN',14),(579,'JACALA DE LEDEZMA',14),(580,'TECOZAUTLA',14),(581,'AGUA BLANCA DE ITURBIDE',14),(582,'JALTOCAN',14),(583,'TENANGO DE DORIA',14),(584,'AJACUBA',14),(585,'JUAREZ HIDALGO',14),(586,'TEPEAPULCO',14),(587,'ALFAJAYUCAN',14),(588,'LOLOTLA',14),(589,'TEPEHUACAN DE GUERRERO',14),(590,'ALMOLOYA',14),(591,'METEPEC',14),(592,'TEPEJI DEL RIO DE OCAMPO',14),(593,'APAN',14),(594,'SAN AGUSTIN METZQUITITLAN',14),(595,'TEPETITLAN',14),(596,'EL ARENAL',14),(597,'METZTITLAN',14),(598,'TETEPANGO',14),(599,'ATITALAQUIA',14),(600,'MINERAL DEL CHICO',14),(601,'VILLA DE TEZONTEPEC',14),(602,'ATLAPEXCO',14),(603,'MINERAL DEL MONTE',14),(604,'TEZONTEPEC DE ALDAMA',14),(605,'ATOTONILCO EL GRANDE',14),(606,'LA MISION',14),(607,'TIANGUISTENGO',14),(608,'ATOTONILCO DE TULA',14),(609,'MIXQUIAHUALA DE JUAREZ',14),(610,'TIZAYUCA',14),(611,'CALNALI',14),(612,'MOLANGO DE ESCAMILLA',14),(613,'TLAHUELILPAN',14),(614,'CARDONAL',14),(615,'NICOLAS FLORES',14),(616,'TLAHUILTEPA',14),(617,'CUAUTEPEC DE HINOJOSA',14),(618,'NOPALA DE VILLAGRAN',14),(619,'TLANALAPA',14),(620,'CHAPANTONGO',14),(621,'OMITLAN DE JUAREZ',14),(622,'TLANCHINOL',14),(623,'CHAPULHUACAN',14),(624,'SAN FELIPE ORIZATLAN',14),(625,'TLAXCOAPAN',14),(626,'CHILCUAUTLA',14),(627,'PACULA',14),(628,'TOLCAYUCA',14),(629,'ELOXOCHITLAN',14),(630,'PACHUCA DE SOTO',14),(631,'TULA DE ALLENDE',14),(632,'EMILIANO ZAPATA',14),(633,'PISAFLORES',14),(634,'TULANCINGO DE BRAVO',14),(635,'EPAZOYUCAN',14),(636,'PROGRESO DE OBREGON',14),(637,'XOCHIATIPAN',14),(638,'FRANCISCO I. MADERO',14),(639,'MINERAL DE LA REFORMA',14),(640,'XOCHICOATLAN',14),(641,'HUASCA DE OCAMPO',14),(642,'SAN AGUSTIN TLAXIACA',14),(643,'YAHUALICA',14),(644,'HUAUTLA',14),(645,'SAN BARTOLO TUTOTEPEC',14),(646,'ZACUALTIPAN DE ANGELES',14),(647,'HUAZALINGO',14),(648,'SAN SALVADOR',14),(649,'ZAPOTLAN DE JUAREZ',14),(650,'HUEHUETLA',14),(651,'SANTIAGO DE ANAYA',14),(652,'ZEMPOALA',14),(653,'HUEJUTLA DE REYES',14),(654,'SANTIAGO TULANTEPEC DE LUGO GUERRERO',14),(655,'ZIMAPAN',14),(656,'ACATIC ',15),(657,'ACATLÁN DE JUÁREZ ',15),(658,'AHUALULCO DE MERCADO ',15),(659,'AMACUECA ',15),(660,'AMATITÁN ',15),(661,'AMECA ',15),(662,'SAN JUANITO DE ESCOBEDO ',15),(663,'ARANDAS ',15),(664,'EL ARENAL ',15),(665,'ATEMAJAC DE BRIZUELA ',15),(666,'ATENGO ',15),(667,'ATENGUILLO ',15),(668,'ATOTONILCO EL ALTO ',15),(669,'ATOYAC ',15),(670,'AUTLÁN DE NAVARRO ',15),(671,'AYOTLÁN ',15),(672,'AYUTLA ',15),(673,'LA BARCA ',15),(674,'BOLAÑOS ',15),(675,'CABO CORRIENTES ',15),(676,'CASIMIRO CASTILLO ',15),(677,'CIHUATLÁN ',15),(678,'ZAPOTLÁN EL GRANDE ',15),(679,'COCULA ',15),(680,'COLOTLÁN ',15),(681,'CONCEPCIÓN DE BUENOS AIRES ',15),(682,'CUAUTITLÁN DE GARCÍA BARRAGÁN ',15),(683,'CUAUTLA ',15),(684,'CUQUÍO ',15),(685,'CHAPALA ',15),(686,'CHIMALTITÁN ',15),(687,'CHIQUILISTLÁN ',15),(688,'DEGOLLADO ',15),(689,'EJUTLA ',15),(690,'ENCARNACIÓN DE DÍAZ ',15),(691,'ETZATLÁN ',15),(692,'EL GRULLO ',15),(693,'GUACHINANGO ',15),(694,'GUADALAJARA ',15),(695,'HOSTOTIPAQUILLO ',15),(696,'HUEJÚCAR ',15),(697,'HUEJUQUILLA EL ALTO ',15),(698,'LA HUERTA ',15),(699,'IXTLAHACÁN DE LOS MEMBRILLOS ',15),(700,'IXTLAHUACÁN DEL RÍO ',15),(701,'JALOSTOTITLÁN ',15),(702,'JAMAY ',15),(703,'JESÚS MARÍA ',15),(704,'JILOTLÁN DE LOS DOLORES ',15),(705,'JOCOTEPEC ',15),(706,'JUANACATLÁN ',15),(707,'JUCHITLÁN ',15),(708,'LAGOS DE MORENO ',15),(709,'EL LIMÓN ',15),(710,'MAGDALENA ',15),(711,'SANTA MARÍA DEL ORO ',15),(712,'LA MANZANILLA DE LA PAZ ',15),(713,'MASCOTA ',15),(714,'MAZAMITLA ',15),(715,'MEXTICACÁN ',15),(716,'MEZQUITIC ',15),(717,'MIXTLÁN ',15),(718,'OCOTLÁN',15),(719,'OJUELOS DE  JALISCO',15),(720,'PIHUAMO',15),(721,'PONCITLÁN',15),(722,'PUERTO VALLARTA',15),(723,'VILLA PURIFICACIÓN',15),(724,'QUITUPAN',15),(725,'EL SALTO',15),(726,'SAN CRISTÓBAL DE LA BARRANCA',15),(727,'SAN DIEGO DE ALEJANDRÍA',15),(728,'SAN JUAN DE LOS LAGOS',15),(729,'SAN JULIÁN',15),(730,'SAN MARCOS',15),(731,'SAN MARTÍN DE BOLAÑOS',15),(732,'SAN MARTÍN HIDALGO',15),(733,'SAN MIGUEL EL ALTO',15),(734,'GÓMEZ FARÍAS',15),(735,'SAN SEBASTIÁN DEL OESTE',15),(736,'SANTA MARÍA DE LOS ÁNGELES',15),(737,'SAYULA',15),(738,'TALA',15),(739,'TALPA DE ALLENDE',15),(740,'TAMAZULA DE GORDIANO',15),(741,'TAPALPA',15),(742,'TECALITLÁN',15),(743,'TECOLOTLÁN',15),(744,'TECHALUTA DE MONTENEGRO',15),(745,'TENAMAXLÁN',15),(746,'TEOCALTICHE',15),(747,'TEOCUITATLÁN DE CORONA',15),(748,'TEPATITLÁN DE MORELOS',15),(749,'TEQUILA',15),(750,'TEUCHITLÁN',15),(751,'TIZAPÁN EL ALTO',15),(752,'TLAJOMULCO DE ZÚÑIGA',15),(753,'TLAQUEPAQUE',15),(754,'TOLIMÁN',15),(755,'TOMATLÁN',15),(756,'TONALÁ',15),(757,'TONAYA',15),(758,'TONILA',15),(759,'TOTATICHE',15),(760,'TOTOTLÁN',15),(761,'TUXCACUESCO',15),(762,'TUXCUECA',15),(763,'TUXPAN',15),(764,'UNIÓN DE SAN ANTONIO',15),(765,'UNIÓN DE TULA',15),(766,'VALLE DE GUADALUPE',15),(767,'VALLE DE JUÁREZ',15),(768,'SAN GABRIEL',15),(769,'VILLA CORONA',15),(770,'VILLA GUERRERO',15),(771,'VILLA HIDALGO',15),(772,'CAÑADAS DE OBREGÓN',15),(773,'YAHUALICA DE GONZÁLEZ GALLO',15),(774,'ZACOALCO DE TORRES',15),(775,'ZAPOPAN',15),(776,'ZAPOTILTIC',15),(777,'ZAPOTITLÁN DE VADILLO',15),(778,'ZAPOTLÁN DEL REY',15),(779,'ZAPOTLANEJO',15),(780,'SAN IGNACIO CERRO GORDO',15),(781,'ACUITZIO',16),(782,'HUIRAMBA',16),(783,'SAN LUCAS',16),(784,'AGUILILLA',16),(785,'INDAPARAPEO',16),(786,'SANTA ANA MAYA',16),(787,'ÁLVARO OBREGÓN',16),(788,'IRIMBO',16),(789,'SALVADOR ESCALANTE',16),(790,'ANGAMACUTIRO',16),(791,'IXTLÁN',16),(792,'SENGUIO',16),(793,'ANGANGUEO',16),(794,'JACONA',16),(795,'SUSUPUATO',16),(796,'APATZINGÁN',16),(797,'JIMÉNEZ',16),(798,'TACÁMBARO',16),(799,'APORO',16),(800,'JIQUILPAN',16),(801,'TANCÍTARO',16),(802,'AQUILA',16),(803,'JUÁREZ',16),(804,'TANGAMANDAPIO',16),(805,'ARIO',16),(806,'JUNGAPEO',16),(807,'TANGANCÍCUARO',16),(808,'ARTEAGA',16),(809,'LAGUNILLAS',16),(810,'TANHUATO',16),(811,'BRISEÑAS',16),(812,'MADERO',16),(813,'TARETAN',16),(814,'BUENAVISTA',16),(815,'MARAVATÍO',16),(816,'TARÍMBARO',16),(817,'CARÁCUARO',16),(818,'MARCOS CASTELLANOS',16),(819,'TEPALCATEPEC',16),(820,'COAHUAYANA',16),(821,'LÁZARO CÁRDENAS',16),(822,'TINGAMBATO',16),(823,'COALCOMÁN DE VÁZQUEZ PALLARES',16),(824,'MORELIA',16),(825,'TINGUINDÍN',16),(826,'COENEO',16),(827,'MORELOS',16),(828,'TIQUICHEO DE NICOLÁS ROMERO',16),(829,'CONTEPEC',16),(830,'MÚGICA',16),(831,'TLALPUJAHUA',16),(832,'COPÁNDARO',16),(833,'NAHUATZEN',16),(834,'TLAZAZALCA',16),(835,'COTIJA',16),(836,'NOCUPÉTARO',16),(837,'TOCUMBO',16),(838,'CUITZEO',16),(839,'NUEVO PARANGARICUTIRO',16),(840,'TUMBISCATÍO',16),(841,'CHARAPAN',16),(842,'NUEVO URECHO',16),(843,'TURICATO',16),(844,'CHARO',16),(845,'NUMARÁN',16),(846,'TUXPAN',16),(847,'CHAVINDA',16),(848,'OCAMPO',16),(849,'TUZANTLA',16),(850,'CHERÁN',16),(851,'PAJACUARÁN',16),(852,'TZINTZUNTZAN',16),(853,'CHILCHOTA',16),(854,'PANINDÍCUARO',16),(855,'TZITZIO',16),(856,'CHINICUILA',16),(857,'PARÁCUARO',16),(858,'URUAPAN',16),(859,'CHUCÁNDIRO',16),(860,'PARACHO',16),(861,'VENUSTIANO CARRANZA',16),(862,'CHURINTZIO',16),(863,'PÁTZCUARO',16),(864,'VILLAMAR',16),(865,'CHURUMUCO',16),(866,'PENJAMILLO',16),(867,'VISTA HERMOSA',16),(868,'ECUANDUREO',16),(869,'PERIBÁN',16),(870,'YURÉCUARO',16),(871,'EPITACIO HUERTA',16),(872,'PIEDAD, LA',16),(873,'ZACAPU',16),(874,'ERONGARÍCUARO',16),(875,'PURÉPERO',16),(876,'ZAMORA',16),(877,'GABRIEL ZAMORA',16),(878,'PURUÁNDIRO',16),(879,'ZINÁPARO',16),(880,'HIDALGO',16),(881,'QUERÉNDARO',16),(882,'ZINAPÉCUARO',16),(883,'HUACANA, LA',16),(884,'QUIROGA',16),(885,'ZIRACUARETIRO',16),(886,'HUANDACAREO',16),(887,'RÉGULES, COJUMATLÁN DE',16),(888,'ZITÁCUARO',16),(889,'HUANIQUEO',16),(890,'REYES, LOS',16),(891,'JOSÉ SIXTO VERDUZCO',16),(892,'HUETAMO',16),(893,'SAHUAYO',16),(894,'VILLA GUERRERO',16),(895,'VILLA HIDALGO',16),(896,'CAÑADAS DE OBREGÓN',16),(897,'YAHUALICA DE GONZÁLEZ GALLO',16),(898,'ZACOALCO DE TORRES',16),(899,'ZAPOPAN',16),(900,'ZAPOTILTIC',16),(901,'ZAPOTITLÁN DE VADILLO',16),(902,'ZAPOTLÁN DEL REY',16),(903,'ZAPOTLANEJO',16),(904,'SAN IGNACIO CERRO GORDO',16),(905,'AMACUZAC ',17),(906,'ATLATLAHUCAN ',17),(907,'AXOCHIAPAN ',17),(908,'AYALA ',17),(909,'COATLAN DEL RÍO ',17),(910,'CUAUTLA ',17),(911,'CUERNAVACA ',17),(912,'EMILIANO ZAPATA ',17),(913,'HUITZILAC ',17),(914,'JANTETELCO ',17),(915,'JIUTEPEC ',17),(916,'JOJUTLA ',17),(917,'JONACATEPEC ',17),(918,'MAZATEPEC ',17),(919,'MIACATLÁN ',17),(920,'OCUITUCO ',17),(921,'PUENTE DE IXTLA ',17),(922,'TEMIXCO ',17),(923,'TEMOAC',17),(924,'TEPALCINGO ',17),(925,'TEPOZTLAN ',17),(926,'TETECALA ',17),(927,'TETELA DEL VOLCÁN ',17),(928,'TLALNEPANTLA',17),(929,'TLALTIZAPAN',17),(930,'TLAQUILTENANGO',17),(931,'TLAYACAPAN',17),(932,'TOTOLAPAN',17),(933,'XOCHITEPEC',17),(934,'YAUTEPEC',17),(935,'YECAPIXTLA',17),(936,'ZACATEPEC',17),(937,'ZACUALPAN DE AMILPAS',17),(938,'ACAPONETA ',18),(939,'AHUACATLÁN ',18),(940,'AMATLÁN DE CAÑAS ',18),(941,'BAHÍA DE BANDERAS',18),(942,'COMPOSTELA ',18),(943,'HUAJICORI ',18),(944,'IXTLÁN DEL RÍO ',18),(945,'JALA ',18),(946,'NAYAR, EL ',18),(947,'ROSAMORADA ',18),(948,'RUÍZ',18),(949,'SAN BLAS',18),(950,'SAN PEDRO LAGUNILLAS',18),(951,'SANTA MARÍA DEL ORO',18),(952,'SANTIAGO IXCUINTLA',18),(953,'TECUALA',18),(954,'TEPIC',18),(955,'TUXPAN',18),(956,'XALISCO ',18),(957,'YESCA, LA',18),(958,'ABASOLO  ',19),(959,'AGUALEGUAS ',19),(960,'ALDAMAS, LOS ',19),(961,'ALLENDE ',19),(962,'ANÁHUAC ',19),(963,'APODACA ',19),(964,'ARAMBERRI ',19),(965,'BUSTAMANTE ',19),(966,'CADEREYTA JIMÉNEZ ',19),(967,'CARMEN, EL ',19),(968,'CERRALVO ',19),(969,'CHINA ',19),(970,'CIÉNEGA DE FLORES ',19),(971,'DOCTOR ARROYO ',19),(972,'DOCTOR COSS ',19),(973,'DOCTOR GONZÁLEZ ',19),(974,'GALEANA ',19),(975,'GARCÍA ',19),(976,'GENERAL BRAVO ',19),(977,'GENERAL ESCOBEDO ',19),(978,'GENERAL TERÁN ',19),(979,'GENERAL TREVIÑO ',19),(980,'GENERAL ZARAGOZA ',19),(981,'GENERAL ZUAZUA ',19),(982,'GUADALUPE ',19),(983,'HERRERAS, LOS ',19),(984,'HIDALGO',19),(985,'HIGUERAS',19),(986,'HUALAHUISES',19),(987,'ITURBIDE',19),(988,'JUÁREZ',19),(989,'LAMPAZOS DE NARANJO',19),(990,'LINARES',19),(991,'MARÍN',19),(992,'MELCHOR OCAMPO',19),(993,'MIER Y NORIEGA',19),(994,'MINA',19),(995,'MONTEMORELOS',19),(996,'MONTERREY',19),(997,'PARÁS',19),(998,'PESQUERÍA',19),(999,'RAMONES, LOS',19),(1000,'RAYONES',19),(1001,'SABINAS HIDALGO',19),(1002,'SALINAS VICTORIA',19),(1003,'SAN NICOLÁS DE LOS GARZA',19),(1004,'SAN PEDRO GARZA GARCÍA',19),(1005,'SANTA CATARINA',19),(1006,'SANTIAGO',19),(1007,'VALLECILLO',19),(1008,'VILLALDAMA',19),(1009,'ABEJONES',20),(1010,'ACATLAN DE PEREZ FIGUEROA',20),(1011,'ANIMAS TRUJANO',20),(1012,'ASUNCION CACALOTEPEC',20),(1013,'ASUNCION CUYOTEPEJI',20),(1014,'ASUNCION IXTALTEPEC',20),(1015,'ASUNCION NOCHIXTLAN',20),(1016,'ASUNCION OCOTLAN',20),(1017,'ASUNCION TLACOLULITA',20),(1018,'AYOQUEZCO DE ALDAMA',20),(1019,'AYOTZINTEPEC',20),(1020,'CALIHUALA',20),(1021,'CANDELARIA LOXICHA',20),(1022,'CAPULALPAM DE MENDEZ',20),(1023,'CIENEGA DE ZIMATLAN',20),(1024,'CIUDAD IXTEPEC',20),(1025,'COATECAS ALTAS',20),(1026,'COICOYAN DE LAS FLORES',20),(1027,'CONCEPCION BUENAVISTA',20),(1028,'CONCEPCION PAPALO',20),(1029,'CONSTANCIA DEL ROSARIO',20),(1030,'COSOLAPA',20),(1031,'COSOLTEPEC',20),(1032,'CUILAPAM DE GUERRERO',20),(1033,'CUYAMECALCO VILLA DE ZARAGOZA',20),(1034,'CHAHUITES',20),(1035,'CHALCATONGO DE HIDALGO',20),(1036,'CHIQUIHUITLAN DE BENITO JUAREZ',20),(1037,'EL BARRIO DE LA SOLEDAD',20),(1038,'EL ESPINAL',20),(1039,'ELOXOCHITLAN DE FLORES MAGON',20),(1040,'FRESNILLO DE TRUJANO',20),(1041,'GUADALUPE DE RAMIREZ',20),(1042,'GUADALUPE ETLA',20),(1043,'GUELATAO DE JUAREZ',20),(1044,'GUEVEA DE HUMBOLDT',20),(1045,'HEROICA CIUDAD DE EJUTLA DE CRESPO',20),(1046,'HEROICA CIUDAD DE HUAJUAPAN DE LEON',20),(1047,'HEROICA CIUDAD DE TLAXIACO',20),(1048,'HUAUTEPEC',20),(1049,'HUAUTLA DE JIMENEZ',20),(1050,'IXPANTEPEC NIEVES',20),(1051,'IXTLAN DE JUAREZ',20),(1052,'JUCHITAN DE ZARAGOZA',20),(1053,'LA COMPAÑIA',20),(1054,'LA PE',20),(1055,'LA REFORMA',20),(1056,'LA TRINIDAD VISTA HERMOSA',20),(1057,'LOMA BONITA',20),(1058,'MAGDALENA APASCO',20),(1059,'MAGDALENA JALTEPEC',20),(1060,'MAGDALENA MIXTEPEC',20),(1061,'MAGDALENA OCOTLAN',20),(1062,'MAGDALENA PEÑASCO',20),(1063,'MAGDALENA TEITIPAC',20),(1064,'MAGDALENA TEQUISISTLAN',20),(1065,'MAGDALENA TLACOTEPEC',20),(1066,'MAGDALENA YODOCONO DE PORFIRIO DIAZ',20),(1067,'MAGDALENA ZAHUATLAN',20),(1068,'MARISCALA DE JUAREZ',20),(1069,'MARTIRES DE TACUBAYA',20),(1070,'MATIAS ROMERO',20),(1071,'MAZATLAN VILLA DE FLORES',20),(1072,'MESONES HIDALGO',20),(1073,'MIAHUATLAN DE PORFIRIO DIAZ',20),(1074,'MIXISTLAN DE LA REFORMA',20),(1075,'MONJAS',20),(1076,'NATIVIDAD',20),(1077,'NAZARENO ETLA',20),(1078,'NEJAPA DE MADERO',20),(1079,'NUEVO ZOQUIAPAM',20),(1080,'OAXACA DE JUAREZ',20),(1081,'OCOTLAN DE MORELOS',20),(1082,'PINOTEPA DE DON LUIS',20),(1083,'PLUMA HIDALGO',20),(1084,'PUTLA VILLA DE GUERRERO',20),(1085,'REFORMA DE PINEDA',20),(1086,'REYES ETLA',20),(1087,'ROJAS DE CUAUHTEMOC',20),(1088,'SALINA CRUZ',20),(1089,'SAN AGUSTIN AMATENGO',20),(1090,'SAN AGUSTIN ATENANGO',20),(1091,'SAN AGUSTIN CHAYUCO',20),(1092,'SAN AGUSTIN DE LAS JUNTAS',20),(1093,'SAN AGUSTIN ETLA',20),(1094,'SAN AGUSTIN LOXICHA',20),(1095,'SAN AGUSTIN TLACOTEPEC',20),(1096,'SAN AGUSTIN YATARENI',20),(1097,'SAN ANDRES CABECERA NUEVA',20),(1098,'SAN ANDRES DINICUITI',20),(1099,'SAN ANDRES HUAXPALTEPEC',20),(1100,'SAN ANDRES HUAYAPAM',20),(1101,'SAN ANDRES IXTLAHUACA',20),(1102,'SAN ANDRES LAGUNAS',20),(1103,'SAN ANDRES NUXIÑO',20),(1104,'SAN ANDRES PAXTLAN',20),(1105,'SAN ANDRES SINAXTLA',20),(1106,'SAN ANDRES SOLAGA',20),(1107,'SAN ANDRES TEOTILALPAM',20),(1108,'SAN ANDRES TEPETLAPA',20),(1109,'SAN ANDRES YAA',20),(1110,'SAN ANDRES ZABACHE',20),(1111,'SAN ANDRES ZAUTLA',20),(1112,'SAN ANTONINO CASTILLO VELASCO',20),(1113,'SAN ANTONINO EL ALTO',20),(1114,'SAN ANTONINO MONTEVERDE',20),(1115,'SAN ANTONIO ACUTLA',20),(1116,'SAN ANTONIO DE LA CAL',20),(1117,'SAN ANTONIO HUITEPEC',20),(1118,'SAN ANTONIO NANAHUATIPAM',20),(1119,'SAN ANTONIO SINICAHUA',20),(1120,'SAN ANTONIO TEPETLAPA',20),(1121,'SAN BALTAZAR CHICHICAPAM',20),(1122,'SAN BALTAZAR LOXICHA',20),(1123,'SAN BALTAZAR YATZACHI EL BAJO',20),(1124,'SAN BARTOLO COYOTEPEC',20),(1125,'SAN BARTOLO SOYALTEPEC',20),(1126,'SAN BARTOLO YAUTEPEC',20),(1127,'SAN BARTOLOME AYAUTLA',20),(1128,'SAN BARTOLOME LOXICHA',20),(1129,'SAN BARTOLOME QUIALANA',20),(1130,'SAN BARTOLOME YUCUAÑE',20),(1131,'SAN BARTOLOME ZOOGOCHO',20),(1132,'SAN BERNARDO MIXTEPEC',20),(1133,'SAN BLAS ATEMPA',20),(1134,'SAN CARLOS YAUTEPEC',20),(1135,'SAN CRISTOBAL AMATLAN',20),(1136,'SAN CRISTOBAL AMOLTEPEC',20),(1137,'SAN CRISTOBAL LACHIRIOAG',20),(1138,'SAN CRISTOBAL SUCHIXTLAHUACA',20),(1139,'SAN DIONISIO DEL MAR',20),(1140,'SAN DIONISIO OCOTEPEC',20),(1141,'SAN DIONISIO OCOTLAN',20),(1142,'SAN ESTEBAN ATATLAHUCA',20),(1143,'SAN FELIPE JALAPA DE DIAZ',20),(1144,'SAN FELIPE TEJALAPAM',20),(1145,'SAN FELIPE USILA',20),(1146,'SAN FRANCISCO CAHUACUA',20),(1147,'SAN FRANCISCO CAJONOS',20),(1148,'SAN FRANCISCO CHAPULAPA',20),(1149,'SAN FRANCISCO CHINDUA',20),(1150,'SAN FRANCISCO DEL MAR',20),(1151,'SAN FRANCISCO HUEHUETLAN',20),(1152,'SAN FRANCISCO IXHUATAN',20),(1153,'SAN FRANCISCO JALTEPETONGO',20),(1154,'SAN FRANCISCO LACHIGOLO',20),(1155,'SAN FRANCISCO LOGUECHE',20),(1156,'SAN FRANCISCO NUXAÑO',20),(1157,'SAN FRANCISCO OZOLOTEPEC',20),(1158,'SAN FRANCISCO SOLA',20),(1159,'SAN FRANCISCO TELIXTLAHUACA',20),(1160,'SAN FRANCISCO TEOPAN',20),(1161,'SAN FRANCISCO TLAPANCINGO',20),(1162,'SAN GABRIEL MIXTEPEC',20),(1163,'SAN ILDEFONSO AMATLAN',20),(1164,'SAN ILDEFONSO SOLA',20),(1165,'SAN ILDEFONSO VILLA ALTA',20),(1166,'SAN JACINTO AMILPAS',20),(1167,'SAN JACINTO TLACOTEPEC',20),(1168,'SAN JERONIMO COATLAN',20),(1169,'SAN JERONIMO SILACAYOAPILLA',20),(1170,'SAN JERONIMO SOSOLA',20),(1171,'SAN JERONIMO TAVICHE',20),(1172,'SAN JERONIMO TECOATL',20),(1173,'SAN JERONIMO TLACOCHAHUAYA',20),(1174,'SAN JORGE NUCHITA',20),(1175,'SAN JOSE AYUQUILA',20),(1176,'SAN JOSE CHILTEPEC',20),(1177,'SAN JOSE DEL PEÑASCO',20),(1178,'SAN JOSE DEL PROGRESO',20),(1179,'SAN JOSE ESTANCIA GRANDE',20),(1180,'SAN JOSE INDEPENDENCIA',20),(1181,'SAN JOSE LACHIGUIRI',20),(1182,'SAN JOSE TENANGO',20),(1183,'SAN JUAN ACHIUTLA',20),(1184,'SAN JUAN ATEPEC',20),(1185,'SAN JUAN BAUTISTA ATATLAHUCA',20),(1186,'SAN JUAN BAUTISTA COIXTLAHUACA',20),(1187,'SAN JUAN BAUTISTA CUICATLAN',20),(1188,'SAN JUAN BAUTISTA GUELACHE',20),(1189,'SAN JUAN BAUTISTA JAYACATLAN',20),(1190,'SAN JUAN BAUTISTA LO DE SOTO',20),(1191,'SAN JUAN BAUTISTA SUCHITEPEC',20),(1192,'SAN JUAN BAUTISTA TLACOATZINTEPEC',20),(1193,'SAN JUAN BAUTISTA TLACHICHILCO',20),(1194,'SAN JUAN BAUTISTA TUXTEPEC',20),(1195,'SAN JUAN BAUTISTA VALLE NACIONAL',20),(1196,'SAN JUAN CACAHUATEPEC',20),(1197,'SAN JUAN CIENEGUILLA',20),(1198,'SAN JUAN COATZOSPAM',20),(1199,'SAN JUAN COLORADO',20),(1200,'SAN JUAN COMALTEPEC',20),(1201,'SAN JUAN COTZOCON',20),(1202,'SAN JUAN CHICOMEZUCHIL',20),(1203,'SAN JUAN CHILATECA',20),(1204,'SAN JUAN DE LOS CUES',20),(1205,'SAN JUAN DEL ESTADO',20),(1206,'SAN JUAN DEL RIO',20),(1207,'SAN JUAN DIUXI',20),(1208,'SAN JUAN EVANGELISTA ANALCO',20),(1209,'SAN JUAN GUELAVIA',20),(1210,'SAN JUAN GUICHICOVI',20),(1211,'SAN JUAN IHUALTEPEC',20),(1212,'SAN JUAN JUQUILA MIXES',20),(1213,'SAN JUAN JUQUILA VIJANOS',20),(1214,'SAN JUAN LACHAO',20),(1215,'SAN JUAN LACHIGALLA',20),(1216,'SAN JUAN LAJARCIA',20),(1217,'SAN JUAN LALANA',20),(1218,'SAN JUAN MAZATLAN',20),(1219,'SAN JUAN MIXTEPEC - DISTR. 08',20),(1220,'SAN JUAN MIXTEPEC - DISTR. 26',20),(1221,'SAN JUAN ÑUMI',20),(1222,'SAN JUAN OZOLOTEPEC',20),(1223,'SAN JUAN PETLAPA',20),(1224,'SAN JUAN QUIAHIJE',20),(1225,'SAN JUAN QUIOTEPEC',20),(1226,'SAN JUAN SAYULTEPEC',20),(1227,'SAN JUAN TABAA',20),(1228,'SAN JUAN TAMAZOLA',20),(1229,'SAN JUAN TEITA',20),(1230,'SAN JUAN TEITIPAC',20),(1231,'SAN JUAN TEPEUXILA',20),(1232,'SAN JUAN TEPOSCOLULA',20),(1233,'SAN JUAN YAEE',20),(1234,'SAN JUAN YATZONA',20),(1235,'SAN JUAN YUCUITA',20),(1236,'SAN LORENZO',20),(1237,'SAN LORENZO ALBARRADAS',20),(1238,'SAN LORENZO CACAOTEPEC',20),(1239,'SAN LORENZO CUAUNECUILTITLA',20),(1240,'SAN LORENZO TEXMELUCAN',20),(1241,'SAN LORENZO VICTORIA',20),(1242,'SAN LUCAS CAMOTLAN',20),(1243,'SAN LUCAS OJITLAN',20),(1244,'SAN LUCAS QUIAVINI',20),(1245,'SAN LUCAS ZOQUIAPAM',20),(1246,'SAN LUIS AMATLAN',20),(1247,'SAN MARCIAL OZOLOTEPEC',20),(1248,'SAN MARCOS ARTEAGA',20),(1249,'SAN MARTIN DE LOS CANSECOS',20),(1250,'SAN MARTIN HUAMELULPAM',20),(1251,'SAN MARTIN ITUNYOSO',20),(1252,'SAN MARTIN LACHILA',20),(1253,'SAN MARTIN PERAS',20),(1254,'SAN MARTIN TILCAJETE',20),(1255,'SAN MARTIN TOXPALAN',20),(1256,'SAN MARTIN ZACATEPEC',20),(1257,'SAN MATEO CAJONOS',20),(1258,'SAN MATEO DEL MAR',20),(1259,'SAN MATEO ETLATONGO',20),(1260,'SAN MATEO NEJAPAM',20),(1261,'SAN MATEO PEÑASCO',20),(1262,'SAN MATEO PIÑAS',20),(1263,'SAN MATEO RIO HONDO',20),(1264,'SAN MATEO SINDIHUI',20),(1265,'SAN MATEO TLAPILTEPEC',20),(1266,'SAN MATEO YOLOXOCHITLAN',20),(1267,'SAN MELCHOR BETAZA',20),(1268,'SAN MIGUEL ACHIUTLA',20),(1269,'SAN MIGUEL AHUEHUETITLAN',20),(1270,'SAN MIGUEL ALOAPAM',20),(1271,'SAN MIGUEL AMATITLAN',20),(1272,'SAN MIGUEL AMATLAN',20),(1273,'SAN MIGUEL COATLAN',20),(1274,'SAN MIGUEL CHICAHUA',20),(1275,'SAN MIGUEL CHIMALAPA',20),(1276,'SAN MIGUEL DEL PUERTO',20),(1277,'SAN MIGUEL DEL RIO',20),(1278,'SAN MIGUEL EJUTLA',20),(1279,'SAN MIGUEL EL GRANDE',20),(1280,'SAN MIGUEL HUAUTLA',20),(1281,'SAN MIGUEL MIXTEPEC',20),(1282,'SAN MIGUEL PANIXTLAHUACA',20),(1283,'SAN MIGUEL PERAS',20),(1284,'SAN MIGUEL PIEDRAS',20),(1285,'SAN MIGUEL QUETZALTEPEC',20),(1286,'SAN MIGUEL SANTA FLOR',20),(1287,'SAN MIGUEL SOYALTEPEC',20),(1288,'SAN MIGUEL SUCHIXTEPEC',20),(1289,'SAN MIGUEL TECOMATLAN',20),(1290,'SAN MIGUEL TENANGO',20),(1291,'SAN MIGUEL TEQUIXTEPEC',20),(1292,'SAN MIGUEL TILQUIAPAM',20),(1293,'SAN MIGUEL TLACAMAMA',20),(1294,'SAN MIGUEL TLACOTEPEC',20),(1295,'SAN MIGUEL TULANCINGO',20),(1296,'SAN MIGUEL YOTAO',20),(1297,'SAN NICOLAS',20),(1298,'SAN NICOLAS HIDALGO',20),(1299,'SAN PABLO COATLAN',20),(1300,'SAN PABLO CUATRO VENADOS',20),(1301,'SAN PABLO ETLA',20),(1302,'SAN PABLO HUITZO',20),(1303,'SAN PABLO HUIXTEPEC',20),(1304,'SAN PABLO MACUILTIANGUIS',20),(1305,'SAN PABLO TIJALTEPEC',20),(1306,'SAN PABLO VILLA DE MITLA',20),(1307,'SAN PABLO YAGANIZA',20),(1308,'SAN PEDRO AMUZGOS',20),(1309,'SAN PEDRO APOSTOL',20),(1310,'SAN PEDRO ATOYAC',20),(1311,'SAN PEDRO CAJONOS',20),(1312,'SAN PEDRO COMITANCILLO',20),(1313,'SAN PEDRO COXCALTEPEC CANTAROS',20),(1314,'SAN PEDRO EL ALTO',20),(1315,'SAN PEDRO HUAMELULA',20),(1316,'SAN PEDRO HUILOTEPEC',20),(1317,'SAN PEDRO IXCATLAN',20),(1318,'SAN PEDRO IXTLAHUACA',20),(1319,'SAN PEDRO JALTEPETONGO',20),(1320,'SAN PEDRO JICAYAN',20),(1321,'SAN PEDRO JOCOTIPAC',20),(1322,'SAN PEDRO JUCHATENGO',20),(1323,'SAN PEDRO MARTIR',20),(1324,'SAN PEDRO MARTIR QUIECHAPA',20),(1325,'SAN PEDRO MARTIR YUCUXACO',20),(1326,'SAN PEDRO MIXTEPEC - DISTR. 22 -',20),(1327,'SAN PEDRO MIXTEPEC - DISTR. 26 -',20),(1328,'SAN PEDRO MOLINOS',20),(1329,'SAN PEDRO NOPALA',20),(1330,'SAN PEDRO OCOPETATILLO',20),(1331,'SAN PEDRO OCOTEPEC',20),(1332,'SAN PEDRO POCHUTLA',20),(1333,'SAN PEDRO QUIATONI',20),(1334,'SAN PEDRO SOCHIAPAM',20),(1335,'SAN PEDRO TAPANATEPEC',20),(1336,'SAN PEDRO TAVICHE',20),(1337,'SAN PEDRO TEOZACOALCO',20),(1338,'SAN PEDRO TEUTILA',20),(1339,'SAN PEDRO TIDAA',20),(1340,'SAN PEDRO TOPILTEPEC',20),(1341,'SAN PEDRO TOTOLAPA',20),(1342,'SAN PEDRO Y SAN PABLO AYUTLA',20),(1343,'SAN PEDRO Y SAN PABLO TEPOSCOLULA',20),(1344,'SAN PEDRO Y SAN PABLO TEQUIXTEPEC',20),(1345,'SAN PEDRO YANERI',20),(1346,'SAN PEDRO YOLOX',20),(1347,'SAN PEDRO YUCUNAMA',20),(1348,'SAN RAYMUNDO JALPAN',20),(1349,'SAN SEBASTIAN ABASOLO',20),(1350,'SAN SEBASTIAN COATLAN',20),(1351,'SAN SEBASTIAN IXCAPA',20),(1352,'SAN SEBASTIAN NICANANDUTA',20),(1353,'SAN SEBASTIAN RIO HONDO',20),(1354,'SAN SEBASTIAN TECOMAXTLAHUACA',20),(1355,'SAN SEBASTIAN TEITIPAC',20),(1356,'SAN SEBASTIAN TUTLA',20),(1357,'SAN SIMON ALMOLONGAS',20),(1358,'SAN SIMON ZAHUATLAN',20),(1359,'SAN VICENTE COATLAN',20),(1360,'SAN VICENTE LACHIXIO',20),(1361,'SAN VICENTE NUÑU',20),(1362,'SANTA ANA',20),(1363,'SANTA ANA ATEIXTLAHUACA',20),(1364,'SANTA ANA CUAUHTEMOC',20),(1365,'SANTA ANA DEL VALLE',20),(1366,'SANTA ANA TAVELA',20),(1367,'SANTA ANA TLAPACOYAN',20),(1368,'SANTA ANA YARENI',20),(1369,'SANTA ANA ZEGACHE',20),(1370,'SANTA CATALINA QUIERI',20),(1371,'SANTA CATARINA CUIXTLA',20),(1372,'SANTA CATARINA IXTEPEJI',20),(1373,'SANTA CATARINA JUQUILA',20),(1374,'SANTA CATARINA LACHATAO',20),(1375,'SANTA CATARINA LOXICHA',20),(1376,'SANTA CATARINA MECHOACAN',20),(1377,'SANTA CATARINA MINAS',20),(1378,'SANTA CATARINA QUIANE',20),(1379,'SANTA CATARINA QUIOQUITANI',20),(1380,'SANTA CATARINA TAYATA',20),(1381,'SANTA CATARINA TICUA',20),(1382,'SANTA CATARINA YOSONOTU',20),(1383,'SANTA CATARINA ZAPOQUILA',20),(1384,'SANTA CRUZ ACATEPEC',20),(1385,'SANTA CRUZ AMILPAS',20),(1386,'SANTA CRUZ DE BRAVO',20),(1387,'SANTA CRUZ ITUNDUJIA',20),(1388,'SANTA CRUZ MIXTEPEC',20),(1389,'SANTA CRUZ NUNDACO',20),(1390,'SANTA CRUZ PAPALUTLA',20),(1391,'SANTA CRUZ TACACHE DE MINA',20),(1392,'SANTA CRUZ TACAHUA',20),(1393,'SANTA CRUZ TAYATA',20),(1394,'SANTA CRUZ XITLA',20),(1395,'SANTA CRUZ XOXOCOTLAN',20),(1396,'SANTA CRUZ ZENZONTEPEC',20),(1397,'SANTA GERTRUDIS',20),(1398,'SANTA INES DE ZARAGOZA',20),(1399,'SANTA INES DEL MONTE',20),(1400,'SANTA INES YATZECHE',20),(1401,'SANTA LUCIA DEL CAMINO',20),(1402,'SANTA LUCIA MIAHUATLAN',20),(1403,'SANTA LUCIA MONTEVERDE',20),(1404,'SANTA LUCIA OCOTLAN',20),(1405,'SANTA MAGDALENA JICOTLAN',20),(1406,'SANTA MARIA ALOTEPEC',20),(1407,'SANTA MARIA APAZCO',20),(1408,'SANTA MARIA ATZOMPA',20),(1409,'SANTA MARIA CAMOTLAN',20),(1410,'SANTA MARIA COLOTEPEC',20),(1411,'SANTA MARIA CORTIJO',20),(1412,'SANTA MARIA COYOTEPEC',20),(1413,'SANTA MARIA CHACHOAPAM',20),(1414,'SANTA MARIA CHILCHOTLA',20),(1415,'SANTA MARIA CHIMALAPA',20),(1416,'SANTA MARIA DEL ROSARIO',20),(1417,'SANTA MARIA DEL TULE',20),(1418,'SANTA MARIA ECATEPEC',20),(1419,'SANTA MARIA GUELACE',20),(1420,'SANTA MARIA GUIENAGATI',20),(1421,'SANTA MARIA HUATULCO',20),(1422,'SANTA MARIA HUAZOLOTITLAN',20),(1423,'SANTA MARIA IPALAPA',20),(1424,'SANTA MARIA IXCATLAN',20),(1425,'SANTA MARIA JACATEPEC',20),(1426,'SANTA MARIA JALAPA DEL MARQUES',20),(1427,'SANTA MARIA JALTIANGUIS',20),(1428,'SANTA MARIA LA ASUNCION',20),(1429,'SANTA MARIA LACHIXIO',20),(1430,'SANTA MARIA MIXTEQUILLA',20),(1431,'SANTA MARIA NATIVITAS',20),(1432,'SANTA MARIA NDUAYACO',20),(1433,'SANTA MARIA OZOLOTEPEC',20),(1434,'SANTA MARIA PAPALO',20),(1435,'SANTA MARIA PEÑOLES',20),(1436,'SANTA MARIA PETAPA',20),(1437,'SANTA MARIA QUIEGOLANI',20),(1438,'SANTA MARIA SOLA',20),(1439,'SANTA MARIA TATALTEPEC',20),(1440,'SANTA MARIA TECOMAVACA',20),(1441,'SANTA MARIA TEMAXCALAPA',20),(1442,'SANTA MARIA TEMAXCALTEPEC',20),(1443,'SANTA MARIA TEOPOXCO',20),(1444,'SANTA MARIA TEPANTLALI',20),(1445,'SANTA MARIA TEXCATITLAN',20),(1446,'SANTA MARIA TLAHUITOLTEPEC',20),(1447,'SANTA MARIA TLALIXTAC',20),(1448,'SANTA MARIA TONAMECA',20),(1449,'SANTA MARIA TOTOLAPILLA',20),(1450,'SANTA MARIA XADANI',20),(1451,'SANTA MARIA YALINA',20),(1452,'SANTA MARIA YAVESIA',20),(1453,'SANTA MARIA YOLOTEPEC',20),(1454,'SANTA MARIA YOSOYUA',20),(1455,'SANTA MARIA YUCUHITI',20),(1456,'SANTA MARIA ZACATEPEC',20),(1457,'SANTA MARIA ZANIZA',20),(1458,'SANTA MARIA ZOQUITLAN',20),(1459,'SANTIAGO AMOLTEPEC',20),(1460,'SANTIAGO APOALA',20),(1461,'SANTIAGO APOSTOL',20),(1462,'SANTIAGO ASTATA',20),(1463,'SANTIAGO ATITLAN',20),(1464,'SANTIAGO AYUQUILILLA',20),(1465,'SANTIAGO CACALOXTEPEC',20),(1466,'SANTIAGO CAMOTLAN',20),(1467,'SANTIAGO COMALTEPEC',20),(1468,'SANTIAGO CHAZUMBA',20),(1469,'SANTIAGO CHOAPAM',20),(1470,'SANTIAGO DEL RIO',20),(1471,'SANTIAGO HUAJOLOTITLAN',20),(1472,'SANTIAGO HUAUCLILLA',20),(1473,'SANTIAGO IHUITLAN PLUMAS',20),(1474,'SANTIAGO IXCUINTEPEC',20),(1475,'SANTIAGO IXTAYUTLA',20),(1476,'SANTIAGO JAMILTEPEC',20),(1477,'SANTIAGO JOCOTEPEC',20),(1478,'SANTIAGO JUXTLAHUACA',20),(1479,'SANTIAGO LACHIGUIRI',20),(1480,'SANTIAGO LALOPA',20),(1481,'SANTIAGO LAOLLAGA',20),(1482,'SANTIAGO LAXOPA',20),(1483,'SANTIAGO LLANO GRANDE',20),(1484,'SANTIAGO MATATLAN',20),(1485,'SANTIAGO MILTEPEC',20),(1486,'SANTIAGO MINAS',20),(1487,'SANTIAGO NACALTEPEC',20),(1488,'SANTIAGO NEJAPILLA',20),(1489,'SANTIAGO NILTEPEC',20),(1490,'SANTIAGO NUNDICHE',20),(1491,'SANTIAGO NUYOO',20),(1492,'SANTIAGO PINOTEPA NACIONAL',20),(1493,'SANTIAGO SUCHILQUITONGO',20),(1494,'SANTIAGO TAMAZOLA',20),(1495,'SANTIAGO TAPEXTLA',20),(1496,'SANTIAGO TENANGO',20),(1497,'SANTIAGO TEPETLAPA',20),(1498,'SANTIAGO TETEPEC',20),(1499,'SANTIAGO TEXCALCINGO',20),(1500,'SANTIAGO TEXTITLAN',20),(1501,'SANTIAGO TILANTONGO',20),(1502,'SANTIAGO TILLO',20),(1503,'SANTIAGO TLAZOYALTEPEC',20),(1504,'SANTIAGO XANICA',20),(1505,'SANTIAGO XIACUI',20),(1506,'SANTIAGO YAITEPEC',20),(1507,'SANTIAGO YAVEO',20),(1508,'SANTIAGO YOLOMECATL',20),(1509,'SANTIAGO YOSONDUA',20),(1510,'SANTIAGO YUCUYACHI',20),(1511,'SANTIAGO ZACATEPEC',20),(1512,'SANTIAGO ZOOCHILA',20),(1513,'SANTO DOMINGO ALBARRADAS',20),(1514,'SANTO DOMINGO ARMENTA',20),(1515,'SANTO DOMINGO CHIHUITAN',20),(1516,'SANTO DOMINGO DE MORELOS',20),(1517,'SANTO DOMINGO INGENIO',20),(1518,'SANTO DOMINGO IXCATLAN',20),(1519,'SANTO DOMINGO NUXAA',20),(1520,'SANTO DOMINGO OZOLOTEPEC',20),(1521,'SANTO DOMINGO PETAPA',20),(1522,'SANTO DOMINGO ROAYAGA',20),(1523,'SANTO DOMINGO TEHUANTEPEC',20),(1524,'SANTO DOMINGO TEOJOMULCO',20),(1525,'SANTO DOMINGO TEPUXTEPEC',20),(1526,'SANTO DOMINGO TLATAYAPAM',20),(1527,'SANTO DOMINGO TOMALTEPEC',20),(1528,'SANTO DOMINGO TONALA',20),(1529,'SANTO DOMINGO TONALTEPEC',20),(1530,'SANTO DOMINGO XAGACIA',20),(1531,'SANTO DOMINGO YANHUITLAN',20),(1532,'SANTO DOMINGO YODOHINO',20),(1533,'SANTO DOMINGO ZANATEPEC',20),(1534,'SANTO TOMAS JALIEZA',20),(1535,'SANTO TOMAS MAZALTEPEC',20),(1536,'SANTO TOMAS OCOTEPEC',20),(1537,'SANTO TOMAS TAMAZULAPAN',20),(1538,'SANTOS REYES NOPALA',20),(1539,'SANTOS REYES PAPALO',20),(1540,'SANTOS REYES TEPEJILLO',20),(1541,'SANTOS REYES YUCUNA',20),(1542,'SILACAYOAPAM',20),(1543,'SITIO DE XITLAPEHUA',20),(1544,'SOLEDAD ETLA',20),(1545,'TAMAZULAPAM DEL ESPIRITU SANTO',20),(1546,'TANETZE DE ZARAGOZA',20),(1547,'TANICHE',20),(1548,'TATALTEPEC DE VALDES',20),(1549,'TEOCOCUILCO DE MARCOS PEREZ',20),(1550,'TEOTITLAN DE FLORES MAGON',20),(1551,'TEOTITLAN DEL VALLE',20),(1552,'TEOTONGO',20),(1553,'TEPELMEME VILLA DE MORELOS',20),(1554,'TEZOATLAN DE SEGURA Y LUNA',20),(1555,'TLACOLULA DE MATAMOROS',20),(1556,'TLACOTEPEC PLUMAS',20),(1557,'TLALIXTAC DE CABRERA',20),(1558,'TOTONTEPEC VILLA DE MORELOS',20),(1559,'TRINIDAD ZAACHILA',20),(1560,'UNION HIDALGO HIDALGO',20),(1561,'VALERIO TRUJANO',20),(1562,'VILLA DE CHILAPA DE DIAZ',20),(1563,'VILLA DE ETLA',20),(1564,'VILLA DE TAMAZULAPAM DEL PROGRESO',20),(1565,'VILLA DE TUTUTEPEC DE MELCHOR OCAMPO',20),(1566,'VILLA DE ZAACHILA',20),(1567,'VILLA DIAZ ORDAZ',20),(1568,'VILLA HIDALGO',20),(1569,'VILLA SOLA DE VEGA',20),(1570,'VILLA TALEA DE CASTRO',20),(1571,'VILLA TEJUPAM DE LA UNION',20),(1572,'YAXE',20),(1573,'YOGANA',20),(1574,'YUTANDUCHI DE GUERRERO',20),(1575,'ZAPOTITLAN DEL RIO',20),(1576,'ZAPOTITLAN LAGUNAS',20),(1577,'ZAPOTITLAN PALMAS',20),(1578,'ZIMATLAN DE ALVAREZ',20),(1579,'ACAJETE ',21),(1580,'ACATENO ',21),(1581,'ACATLÁN ',21),(1582,'ACATZINGO ',21),(1583,'ACTEOPAN ',21),(1584,'AHUACATLÁN ',21),(1585,'AHUATLÁN ',21),(1586,'AHUAZOTEPEC ',21),(1587,'AHUEHUETITLA ',21),(1588,'AJALPAN ',21),(1589,'ALBINO ZERTUCHE ',21),(1590,'ALJOJUCA ',21),(1591,'ALTEPEXI ',21),(1592,'AMIXTLÁN ',21),(1593,'AMOZOC ',21),(1594,'AQUIXTLA ',21),(1595,'ATEMPAN ',21),(1596,'ATEXCAL ',21),(1597,'ATLIXCO ',21),(1598,'ATOYATEMPAN ',21),(1599,'ATZALA ',21),(1600,'ATZITZIHUACÁN ',21),(1601,'ATZITZINTLA ',21),(1602,'AXUTLA ',21),(1603,'AYOTOXCO DE GUERRERO ',21),(1604,'CALPAN ',21),(1605,'CALTEPEC ',21),(1606,'CAMOCUAUTLA ',21),(1607,'CAXHUACAN ',21),(1608,'COATEPEC ',21),(1609,'COATZINGO ',21),(1610,'COHETZALA ',21),(1611,'COHUECÁN ',21),(1612,'CORONANGO ',21),(1613,'COXCATLÁN ',21),(1614,'COYOMEAPAN ',21),(1615,'COYOTEPEC ',21),(1616,'CUAPIAXTLA DE MADERO ',21),(1617,'CUAUTEMPAN ',21),(1618,'CUANTINCHÁN ',21),(1619,'CUAUTLANCINGO ',21),(1620,'COAYUCA DE ANDRADE ',21),(1621,'CUETZALAN DEL PROGRESO ',21),(1622,'CUYOACO ',21),(1623,'CHALCHICOMULA DE SESMA ',21),(1624,'CHAPULCO ',21),(1625,'CHIAUTLA ',21),(1626,'CHIAUTZINGO ',21),(1627,'CHICONCUAUTLA ',21),(1628,'CHICHIQUILA ',21),(1629,'CHIETLA ',21),(1630,'CHIGMECATITLAN ',21),(1631,'CHIGNAHUAPAN ',21),(1632,'CHIGNAUTLA ',21),(1633,'CHILA ',21),(1634,'CHILA DE LA SAL ',21),(1635,'HONEY ',21),(1636,'CHILCHOTLA ',21),(1637,'CHINANTLA ',21),(1638,'DOMINGO ARENAS ',21),(1639,'ELOXOCHITLÁN ',21),(1640,'EPATLÁN ',21),(1641,'ESPERANZA ',21),(1642,'FRANCISCO Z. MENA ',21),(1643,'GENERAL FELIPE ANGELES ',21),(1644,'GUADALUPE ',21),(1645,'GUADALUPE VICTORIA ',21),(1646,'HERMENEGILDO GALEANA ',21),(1647,'HUAQUECHULA ',21),(1648,'HUATLATLAUCA ',21),(1649,'HUAUCHINANGO ',21),(1650,'HUEHUETLA ',21),(1651,'HUEHUETLÁN EL CHICO ',21),(1652,'HUEJOTZINGO ',21),(1653,'HUEYAPAN ',21),(1654,'HUEYTAMALCO ',21),(1655,'HUEYTLALPAN ',21),(1656,'HUITZILAN DE SERDÁN ',21),(1657,'HUITZILTEPEC ',21),(1658,'ATLEQUIZAYAN ',21),(1659,'IXCAMILPA DE GUERRERO ',21),(1660,'IXCAQUIXTLA ',21),(1661,'IXTACAMAXTITLÁN ',21),(1662,'IXTEPEC ',21),(1663,'IZÚCAR DE MATAMOROS ',21),(1664,'JALPAN ',21),(1665,'JOLALPAN ',21),(1666,'JONOTLA ',21),(1667,'JOPALA ',21),(1668,'JUAN C. BONILLA ',21),(1669,'JUAN GALINDO ',21),(1670,'JUAN N. MÉNDEZ ',21),(1671,'LAFRAGUA ',21),(1672,'LIBRES ',21),(1673,'MAGDALENA TLATLAUQUITEPEC, LA ',21),(1674,'MAZAPILTEPEC DE JUÁREZ ',21),(1675,'MIXTLA ',21),(1676,'MOLCAXAC ',21),(1677,'MORELOS CAÑADA ',21),(1678,'NAUPAN ',21),(1679,'NAUZONTLA ',21),(1680,'NEALTICAN ',21),(1681,'NICOLÁS BRAVO ',21),(1682,'NOPALUCAN ',21),(1683,'OCOTEPEC ',21),(1684,'OCOYUCAN ',21),(1685,'OLINTLA ',21),(1686,'ORIENTAL ',21),(1687,'PAHUATLÁN ',21),(1688,'PALMAR DE BRAVO ',21),(1689,'PANTEPEC ',21),(1690,'PETLALCINGO ',21),(1691,'PIAXTLA ',21),(1692,'PUEBLA ',21),(1693,'QUECHOLAC ',21),(1694,'QUIMIXTLÁN ',21),(1695,'RAFAEL LARA GRAJALES ',21),(1696,'REYES DE JUÁREZ, LOS ',21),(1697,'SAN ANDRÉS CHOLULA ',21),(1698,'SAN ANTONIO CAÑADA ',21),(1699,'SAN DIEGO LA MEZA TOCHIMILTZINGO ',21),(1700,'SAN FELIPE TEOTLALCINGO ',21),(1701,'SAN FELIPE TEPATLÁN ',21),(1702,'SAN GABRIEL CHILAC ',21),(1703,'SAN GREGORIO ATZOMPA ',21),(1704,'SAN JERÓNIMO TECUANIPAN ',21),(1705,'SAN JERÓNIMO XAYACATLÁN ',21),(1706,'SAN JOSÉ CHIAPA ',21),(1707,'SAN JOSÉ MIAHUATLÁN ',21),(1708,'SAN JUAN ATENCO ',21),(1709,'SAN JUAN ATZOMPA ',21),(1710,'SAN MARTÍN TEXMELUCAN ',21),(1711,'SAN MARTÍN TOTOLTEPEC ',21),(1712,'SAN MATÍAS TLALANCALECA ',21),(1713,'SAN MIGUEL IXITLÁN ',21),(1714,'SAN MIGUEL XOXTLA ',21),(1715,'SAN NICOLÁS BUENOS AIRES ',21),(1716,'SAN NICOLÁS DE LOS RANCHOS ',21),(1717,'SAN PABLO ANICANO ',21),(1718,'SAN PEDRO CHOLULA ',21),(1719,'SAN PEDRO YELOIXTLAHUACA ',21),(1720,'SAN SALVADOR EL SECO ',21),(1721,'SAN SALVADOR EL VERDE ',21),(1722,'SAN SALVADOR HUIXCOLOTLA ',21),(1723,'SAN SEBASTIÁN TLACOTEPEC ',21),(1724,'SANTA CATARINA TLALTEMPAN ',21),(1725,'SANTA INÉS AHUATEMPAN',21),(1726,'SANTA ISABEL CHOLULA',21),(1727,'SANTIAGO MIAHUATLÁN',21),(1728,'HUEHUETLÁN EL GRANDE',21),(1729,'SANTO TOMÁS HUEYOTLIPAN',21),(1730,'SOLTEPEC',21),(1731,'TECALI DE HERRERA',21),(1732,'TECAMACHALCO',21),(1733,'TECOMATLÁN',21),(1734,'TEHUACÁN',21),(1735,'TEHUITZINGO',21),(1736,'TENAMPULCO',21),(1737,'TEOPANTLÁN',21),(1738,'TEOTLALCO',21),(1739,'TEPANCO DE LÓPEZ',21),(1740,'TEPANGO DE RODRÍGUEZ',21),(1741,'TEPATLAXCO DE HIDALGO',21),(1742,'TEPEACA',21),(1743,'TEPEMAXALCO',21),(1744,'TEPEOJUMA',21),(1745,'TEPETZINTLA',21),(1746,'TEPEXCO',21),(1747,'TEPEXI DE RODRÍGUEZ',21),(1748,'TEPEYAHUALCO',21),(1749,'TEPEYAHUALCO DE CUAUHTÉMOC',21),(1750,'TETELA DE OCAMPO',21),(1751,'TETELES DE ÁVILA CASTILLO',21),(1752,'TEZIUTLÁN',21),(1753,'TIANGUISMANALCO',21),(1754,'TILAPA',21),(1755,'TLACOTEPEC DE BENITO JUÁREZ',21),(1756,'TLACUILOTEPEC',21),(1757,'TLACHICHUCA',21),(1758,'TLAHUAPAN',21),(1759,'TLALTENANGO',21),(1760,'TLANEPANTLA',21),(1761,'TLAOLA',21),(1762,'TLAPACOYA',21),(1763,'TLAPANALÁ',21),(1764,'TLATLAUQUITEPEC',21),(1765,'TLAXCO',21),(1766,'TOCHIMILCO',21),(1767,'TOCHTEPEC',21),(1768,'TOTOLTEPEC DE GUERRERO',21),(1769,'TULCINGO',21),(1770,'TUZAMAPAN DE GALEANA',21),(1771,'TZICATLACOYAN',21),(1772,'VENUSTIANO CARRANZA',21),(1773,'VICENTE GUERRERO',21),(1774,'XAYACATLÁN DE BRAVO',21),(1775,'XICOTEPEC',21),(1776,'XICOTLÁN',21),(1777,'XIUTETELCO',21),(1778,'XOCHIAPULCO',21),(1779,'XOCHILTEPEC',21),(1780,'XOCHITLÁN DE VICENTE SUÁREZ',21),(1781,'XOCHITLÁN TODOS SANTOS',21),(1782,'YAONÁHUAC',21),(1783,'YEHUALTEPEC',21),(1784,'ZACAPALA',21),(1785,'ZACAPOAXTLA',21),(1786,'ZACATLÁN',21),(1787,'ZAPOTITLÁN',21),(1788,'ZAPOTITLÁN DE MÉNDEZ',21),(1789,'ZARAGOZA',21),(1790,'ZAUTLA',21),(1791,'ZIHUATEUTLA',21),(1792,'ZINACATEPEC',21),(1793,'ZONGOZOTLA',21),(1794,'ZOQUIAPAN',21),(1795,'ZOQUITLÁN',21),(1796,'AMEALCO DE BONFIL ',22),(1797,'ARROYO SECO ',22),(1798,'CADEREYTA DE MONTES ',22),(1799,'COLÓN ',22),(1800,'CORREGIDORA ',22),(1801,'EL MARQUÉS',22),(1802,'EZEQUIEL MONTES ',22),(1803,'HUIMILPAN ',22),(1804,'JALPAN DE SERRA ',22),(1805,'LANDA DE MATAMOROS ',22),(1806,'PEDRO ESCOBEDO',22),(1807,'PEÑAMILLER',22),(1808,'PINAL DE AMOLES',22),(1809,'QUERÉTARO',22),(1810,'SAN JOAQUÍN',22),(1811,'SAN JUAN DEL RÍO',22),(1812,'TEQUISQUIAPAN',22),(1813,'TOLIMÁN',22),(1814,'COZUMEL ',23),(1815,'FELIPE CARRILLO PUERTO ',23),(1816,'ISLA MUJERES ',23),(1817,'OTHÓN P. BLANCO ',23),(1818,'BENITO JUÁREZ',23),(1819,'JOSÉ MARÍA MORELOS',23),(1820,'LÁZARO CÁRDENAS',23),(1821,'SOLIDARIDAD',23),(1822,'AHUALULCO  ',24),(1823,'ALAQUINES ',24),(1824,'AQUISMÓN ',24),(1825,'ARMADILLO DE LOS INFANTE ',24),(1826,'AXTLA DE TERRAZAS ',24),(1827,'CÁRDENAS ',24),(1828,'CATORCE ',24),(1829,'CEDRAL ',24),(1830,'CERRITOS ',24),(1831,'CERRO DE SAN PEDRO ',24),(1832,'CIUDAD DEL MAÍZ ',24),(1833,'CIUDAD FERNÁNDEZ ',24),(1834,'CIUDAD VALLES ',24),(1835,'COXCATLÁN ',24),(1836,'CHARCAS ',24),(1837,'ÉBANO  ',24),(1838,'GUADALCÁZAR ',24),(1839,'HUEHUETLÁN ',24),(1840,'LAGUNILLAS ',24),(1841,'MATEHUALA ',24),(1842,'MATLAPA ',24),(1843,'MEXQUITIC DE CARMONA ',24),(1844,'MOCTEZUMA ',24),(1845,'EL NARANJO ',24),(1846,'RAYÓN ',24),(1847,'RIOVERDE ',24),(1848,'SALINAS ',24),(1849,'SAN ANTONIO ',24),(1850,'SAN CIRO DE ACOSTA ',24),(1851,'SAN LUIS POTOSÍ ',24),(1852,'SAN MARTÍN CHALCHICUAUTLA  ',24),(1853,'SAN NICOLÁS TOLENTINO ',24),(1854,'SAN VICENTE TANCUAYALAB ',24),(1855,'SANTA CATARINA ',24),(1856,'SANTA MARÍA DEL RÍO ',24),(1857,'SANTO DOMINGO ',24),(1858,'SOLEDAD DE GRACIANO SÁNCHEZ ',24),(1859,'TAMASOPO ',24),(1860,'TAMAZUNCHALE ',24),(1861,'TAMPACÁN ',24),(1862,'TAMPAMOLÓN CORONA ',24),(1863,'TAMUÍN ',24),(1864,'TANCANHUITZ DE SANTOS ',24),(1865,'TANLAJÁS ',24),(1866,'TANQUIÁN DE ESCOBEDO',24),(1867,'TIERRANUEVA',24),(1868,'VANEGAS',24),(1869,'VENADO',24),(1870,'VILLA DE ARISTA',24),(1871,'VILLA DE ARRIAGA',24),(1872,'VILLA DE GUADALUPE',24),(1873,'VILLA DE LA PAZ',24),(1874,'VILLA DE RAMOS',24),(1875,'VILLA DE REYES',24),(1876,'VILLA HIDALGO',24),(1877,'VILLA JUÁREZ',24),(1878,'XILITLA',24),(1879,'ZARAGOZA',24),(1880,'AHOME ',25),(1881,'ANGOSTURA ',25),(1882,'BADIRAGUATO ',25),(1883,'CONCORDIA ',25),(1884,'COSALÁ ',25),(1885,'CULIACÁN ',25),(1886,'CHOIX ',25),(1887,'ELOTA ',25),(1888,'ESCUINAPA ',25),(1889,'FUERTE, EL',25),(1890,'GUASAVE',25),(1891,'MAZATLÁN',25),(1892,'MOCORITO',25),(1893,'NAVOLATO',25),(1894,'ROSARIO',25),(1895,'SALVADOR ALVARADO',25),(1896,'SAN IGNACIO',25),(1897,'SINALOA',25),(1898,'ACONCHI ',26),(1899,'AGUA PRIETA ',26),(1900,'ALAMOS ',26),(1901,'ALTAR ',26),(1902,'ARIVECHI ',26),(1903,'ARIZPE ',26),(1904,'ATIL ',26),(1905,'BACADÉHUACHI ',26),(1906,'BACANORA ',26),(1907,'BACERAC ',26),(1908,'BACOACHI ',26),(1909,'BÁCUM ',26),(1910,'BANÁMICHI ',26),(1911,'BAVIÁCORA ',26),(1912,'BAVISPE ',26),(1913,'BENJAMÍN HILL ',26),(1914,'CABORCA ',26),(1915,'CAJEME ',26),(1916,'CANANEA ',26),(1917,'CARBÓ ',26),(1918,'LA COLORADA ',26),(1919,'CUCURPE ',26),(1920,'CUMPAS ',26),(1921,'DIVISADEROS ',26),(1922,'EMPALME ',26),(1923,'ETCHOJOA ',26),(1924,'FRONTERAS ',26),(1925,'GRANADOS ',26),(1926,'GUAYMAS ',26),(1927,'HERMOSILLO ',26),(1928,'HUACHINERA ',26),(1929,'HUÁSABAS ',26),(1930,'HUATABAMPO ',26),(1931,'HUÉPAC ',26),(1932,'IMURIS ',26),(1933,'MAGDALENA ',26),(1934,'MAZATÁN ',26),(1935,'MOCTEZUMA ',26),(1936,'NACO ',26),(1937,'NÁCORI CHICO ',26),(1938,'NACOZARI DE GARCÍA ',26),(1939,'NAVOJOA ',26),(1940,'NOGALES ',26),(1941,'ONAVAS ',26),(1942,'OPODEPE ',26),(1943,'OQUITOA ',26),(1944,'PITIQUITO ',26),(1945,'PUERTO PEÑASCO ',26),(1946,'QUIRIEGO',26),(1947,'RAYÓN',26),(1948,'ROSARIO',26),(1949,'SAHUARIPA',26),(1950,'SAN FELIPE DE JESÚS',26),(1951,'SAN JAVIER',26),(1952,'SAN LUIS RÍO COLORADO',26),(1953,'SAN MIGUEL DE HORCASITAS',26),(1954,'SAN PEDRO DE LA CUEVA',26),(1955,'SANTA ANA',26),(1956,'SANTA CRUZ',26),(1957,'SÁRIC',26),(1958,'SOYOPA',26),(1959,'SUAQUI GRANDE',26),(1960,'TEPACHI',26),(1961,'TRINCHERAS',26),(1962,'TUBUTAMA',26),(1963,'URES',26),(1964,'VILLA HIDALGO',26),(1965,'VILLA PESQUEIRA',26),(1966,'YÉCORA',26),(1967,'PLUTARCO ELÍAS CALLES',26),(1968,'BENITO JUÁREZ',26),(1969,'SAN IGNACIO RÍO MUERTO',26),(1970,'BALANCÁN ',27),(1971,'CÁRDENAS ',27),(1972,'CENTLA ',27),(1973,'CENTRO ',27),(1974,'COMALCALCO ',27),(1975,'CUNDUACÁN ',27),(1976,'EMILIANO ZAPATA ',27),(1977,'HUIMANGUILLO ',27),(1978,'JALAPA ',27),(1979,'JALPA DE MÉNDEZ',27),(1980,'JONUTA',27),(1981,'MACUSPANA',27),(1982,'NACAJUCA',27),(1983,'PARAÍSO',27),(1984,'TACOTALPA',27),(1985,'TEAPA',27),(1986,'TENOSIQUE',27),(1987,'ABASOLO ',28),(1988,'ALDAMA ',28),(1989,'ALTAMIRA ',28),(1990,'ANTIGUO MORELOS ',28),(1991,'BURGOS ',28),(1992,'BUSTAMANTE ',28),(1993,'CAMARGO ',28),(1994,'CASAS ',28),(1995,'CIUDAD MADERO ',28),(1996,'CRUILLAS ',28),(1997,'GÓMEZ FARÍAS ',28),(1998,'GONZÁLEZ ',28),(1999,'GUÉMEZ ',28),(2000,'GUERRERO ',28),(2001,'GUSTAVO DÍAZ ORDAZ ',28),(2002,'HIDALGO ',28),(2003,'JAUMAVE ',28),(2004,'JIMÉNEZ ',28),(2005,'LLERA ',28),(2006,'MAINERO ',28),(2007,'EL MANTE ',28),(2008,'MATAMOROS ',28),(2009,'MÉNDEZ ',28),(2010,'MIER ',28),(2011,'MIGUEL ALEMÁN ',28),(2012,'MIQUIHUANA ',28),(2013,'NUEVO LAREDO ',28),(2014,'NUEVO MORELOS ',28),(2015,'OCAMPO ',28),(2016,'PADILLA ',28),(2017,'PALMILLAS ',28),(2018,'REYNOSA ',28),(2019,'RÍO BRAVO ',28),(2020,'SAN CARLOS',28),(2021,'SAN FERNANDO',28),(2022,'SAN NICOLÁS',28),(2023,'SOTO LA MARINA',28),(2024,'TAMPICO',28),(2025,'TULA',28),(2026,'VALLE HERMOSO',28),(2027,'VICTORIA',28),(2028,'VILLAGRÁN',28),(2029,'XICOTÉNCATL',28),(2030,'AMAXAC DE GUERRERO',29),(2031,'TETLA DE LA SOLIDARIDAD',29),(2032,'APETATITLÁN DE ANTONIO CARVAJAL',29),(2033,'TETLATLAHUCA',29),(2034,'ATLANGATEPEC',29),(2035,'TLAXCALA',29),(2036,'ALTZAYANCA',29),(2037,'TLAXCO',29),(2038,'APIZACO',29),(2039,'TOCATLÁN',29),(2040,'CALPULALPAN',29),(2041,'TOTOLAC',29),(2042,'EL CARMEN TEQUEXQUITLA',29),(2043,'ZITLALTEPEC DE TRINIDAD SÁNCHEZ SANTOS',29),(2044,'CUAPIAXTLA',29),(2045,'TZOMPANTEPEC',29),(2046,'CUAXOMULCO',29),(2047,'XALOSTOC',29),(2048,'CHIAUTEMPAN',29),(2049,'XALTOCAN',29),(2050,'MUÑOZ DE DOMINGO ARENAS',29),(2051,'PAPALOTLA DE XICOHTÉNCATL',29),(2052,'ESPAÑITA',29),(2053,'XICOHTZINCO',29),(2054,'HUAMANTLA',29),(2055,'YAUHQUEMECAN',29),(2056,'HUEYOTLIPAN',29),(2057,'ZACATELCO',29),(2058,'IXTACUIXTLA DE MARIANO MATAMOROS',29),(2059,'BENITO JUÁREZ',29),(2060,'IXTENCO',29),(2061,'EMILIANO ZAPATA',29),(2062,'MAZATECOCHCO DE JOSÉ MARÍA MORELOS',29),(2063,'LÁZARO CÁRDENAS',29),(2064,'CONTLA DE  JUAN CUAMATZI',29),(2065,'LA MAGDALENA TLALTELULCO',29),(2066,'TEPETITLA DE LARDIZÁBAL',29),(2067,'SAN DAMIÁN TEXOLOC',29),(2068,'SANCTORUM DE LÁZARO CÁRDENAS',29),(2069,'SAN FRANCISCO TETLANOHCAN',29),(2070,'NANACAMILPA DE MARIANO ARISTA',29),(2071,'SAN JERÓNIMO ZACUALPAN',29),(2072,'ACUAMANALA DE MIGUEL HIDALGO',29),(2073,'SAN JOSÉ  TEACALCO',29),(2074,'NATIVITAS',29),(2075,'SAN JUAN HUACTZINCO',29),(2076,'PANOTLA',29),(2077,'SAN LORENZO AXOCOMANITLA',29),(2078,'SAN PABLO DEL MONTE',29),(2079,'SAN LUCAS TECOPILCO',29),(2080,'SANTA CRUZ TLAXCALA',29),(2081,'SANTA ANA NOPALUCAN',29),(2082,'TENANCINGO',29),(2083,'SANTA APOLONIA TEACALCO',29),(2084,'TEOLOCHOLCO',29),(2085,'SANTA CATARINA AYOMETLA',29),(2086,'TEPEYANCO',29),(2087,'SANTA CRUZ QUILEHTLA',29),(2088,'TERRENATE',29),(2089,'SANTA ISABEL XILOXOXTLA',29),(2090,'ACAJETE  ',30),(2091,'ACATLÁN ',30),(2092,'ACAYUCAN ',30),(2093,'ACTOPAN ',30),(2094,'ACULA ',30),(2095,'ACULTZINGO ',30),(2096,'AGUA DULCE',30),(2097,'ALPATLÁHUAC ',30),(2098,'ALTO LUCERO DE GUTIÉRREZ BARRIOS ',30),(2099,'ALTOTONGA ',30),(2100,'ALVARADO ',30),(2101,'AMATITLÁN ',30),(2102,'AMATLÁN DE LOS REYES ',30),(2103,'ANGEL R. CABADA ',30),(2104,'ANTIGUA, LA ',30),(2105,'APAZAPAN ',30),(2106,'AQUILA ',30),(2107,'ASTACINGA ',30),(2108,'ATLAHUILCO ',30),(2109,'ATOYAC ',30),(2110,'ATZACAN ',30),(2111,'ATZALAN ',30),(2112,'AYAHUALULCO ',30),(2113,'BANDERILLA ',30),(2114,'BENITO JUÁREZ ',30),(2115,'BOCA DEL RÍO ',30),(2116,'CALCAHUALCO ',30),(2117,'CAMARÓN DE TEJEDA ',30),(2118,'CAMERINO Z. MENDOZA ',30),(2119,'CARLOS A. CARRILLO',30),(2120,'CARRILLO PUERTO ',30),(2121,'CASTILLO DE TEAYO',30),(2122,'CATEMACO ',30),(2123,'CAZONES DE HERRERA ',30),(2124,'CERRO AZUL ',30),(2125,'CHACALTIANGUIS ',30),(2126,'CHALMA ',30),(2127,'CHICONAMEL ',30),(2128,'CHICONQUIACO ',30),(2129,'CHICONTEPEC ',30),(2130,'CHINAMECA ',30),(2131,'CHINAMPA DE GOROSTIZA ',30),(2132,'CHOAPAS, LAS ',30),(2133,'CHOCAMÁN ',30),(2134,'CHONTLA ',30),(2135,'CHUMATLÁN ',30),(2136,'CITLALTÉPETL ',30),(2137,'COACOATZINTLA ',30),(2138,'COAHUITLÁN ',30),(2139,'COATEPEC ',30),(2140,'COATZACOALCOS ',30),(2141,'COATZINTLA ',30),(2142,'COETZALA ',30),(2143,'COLIPA ',30),(2144,'COMAPA ',30),(2145,'CÓRDOBA ',30),(2146,'COSAMALOAPAN ',30),(2147,'COSAUTLÁN DE CARVAJAL ',30),(2148,'COSCOMATEPEC ',30),(2149,'COSOLEACAQUE ',30),(2150,'COTAXTLA ',30),(2151,'COXQUIHUI ',30),(2152,'COYUTLA ',30),(2153,'CUICHAPA ',30),(2154,'CUITLÁHUAC ',30),(2155,'EMILIANO ZAPATA ',30),(2156,'ESPINAL ',30),(2157,'FILOMENO MATA ',30),(2158,'FORTÍN ',30),(2159,'GUTIÉRREZ ZAMORA ',30),(2160,'HIDALGOTITLÁN ',30),(2161,'HIGO, EL',30),(2162,'HUATUSCO ',30),(2163,'HUAYACOCOTLA ',30),(2164,'HUEYAPAN DE OCAMPO ',30),(2165,'HUILOAPAN DE CUAUHTÉMOC ',30),(2166,'IGNACIO DE LA LLAVE ',30),(2167,'ILAMATLÁN ',30),(2168,'ISLA ',30),(2169,'IXCATEPEC ',30),(2170,'IXHUACÁN DE LOS REYES ',30),(2171,'IXHUATLAN DE MADERO ',30),(2172,'IXHUATLÁN DEL CAFE ',30),(2173,'IXHUATLÁN DEL SURESTE ',30),(2174,'IXHUATLANCILLO ',30),(2175,'IXMATLAHUACAN ',30),(2176,'IXTACZOQUITLÁN ',30),(2177,'JALACINGO ',30),(2178,'JALCOMULCO ',30),(2179,'JÁLTIPAN ',30),(2180,'JAMAPA ',30),(2181,'JESÚS CARRANZA ',30),(2182,'JILOTEPEC ',30),(2183,'JOSÉ AZUETA',30),(2184,'JUAN RODRÍGUEZ CLARA ',30),(2185,'JUCHIQUE DE FERRER ',30),(2186,'LANDERO Y COSS ',30),(2187,'LERDO DE TEJADA ',30),(2188,'MAGDALENA ',30),(2189,'MALTRATA ',30),(2190,'MANLIO FABIO ALTAMIRANO ',30),(2191,'MARIANO ESCOBEDO ',30),(2192,'MARTÍNEZ DE LA TORRE ',30),(2193,'MECATLÁN ',30),(2194,'MECAYAPAN ',30),(2195,'MEDELLÍN ',30),(2196,'MIAHUATLÁN',30),(2197,'MINAS, LAS',30),(2198,'MINATITLÁN',30),(2199,'MISANTLA',30),(2200,'MIXTLA DE ALTAMIRANO',30),(2201,'MOLOACÁN',30),(2202,'NANCHITAL DE LÁZARO CARDENAS DEL RÍO',30),(2203,'NAOLINCO',30),(2204,'NARANJAL',30),(2205,'NARANJOS-AMATLÁN ',30),(2206,'NAUTLA',30),(2207,'NOGALES',30),(2208,'OLUTA',30),(2209,'OMEALCA',30),(2210,'ORIZABA',30),(2211,'OTATITLÁN',30),(2212,'OTEAPAN',30),(2213,'OZULUAMA',30),(2214,'PAJAPAN',30),(2215,'PÁNUCO',30),(2216,'PAPANTLA',30),(2217,'PASO DE OVEJAS',30),(2218,'PASO DEL MACHO',30),(2219,'PERLA, LA',30),(2220,'PEROTE',30),(2221,'PLATÓN SÁNCHEZ',30),(2222,'PLAYA VICENTE',30),(2223,'POZA RICA DE HIDALGO',30),(2224,'PUEBLO VIEJO',30),(2225,'PUENTE NACIONAL',30),(2226,'RAFAEL DELGADO',30),(2227,'RAFAEL LUCIO',30),(2228,'REYES, LOS',30),(2229,'RÍO BLANCO',30),(2230,'SALTABARRANCA',30),(2231,'SAN ANDRÉS TENEJAPAN',30),(2232,'SAN ANDRÉS TUXTLA',30),(2233,'SAN JUAN EVANGELISTA',30),(2234,'SAN RAFAEL ',30),(2235,'SANTIAGO SOCHIAPAN',30),(2236,'SANTIAGO TUXTLA',30),(2237,'SAYULA DE ALEMÁN',30),(2238,'SOCHIAPA',30),(2239,'SOCONUSCO',30),(2240,'SOLEDAD ATZOMPA',30),(2241,'SOLEDAD DE DOBLADO',30),(2242,'SOTEAPAN',30),(2243,'TAMALÍN',30),(2244,'TAMIAHUA',30),(2245,'TAMPICO ALTO',30),(2246,'TANCOCO',30),(2247,'TANTIMA',30),(2248,'TANTOYUCA',30),(2249,'TATAHUICAPAN DE JUÁREZ',30),(2250,'TATATILA',30),(2251,'TECOLUTLA',30),(2252,'TEHUIPANGO',30),(2253,'TEMAPACHE',30),(2254,'TEMPOAL',30),(2255,'TENAMPA',30),(2256,'TENOCHTITLÁN',30),(2257,'TEOCELO',30),(2258,'TEPATLAXCO',30),(2259,'TEPETLÁN',30),(2260,'TEPETZINTLA',30),(2261,'TEQUILA',30),(2262,'TEXCATEPEC',30),(2263,'TEXHUACÁN',30),(2264,'TEXISTEPEC',30),(2265,'TEZONAPA',30),(2266,'TIERRA BLANCA',30),(2267,'TIHUATLÁN',30),(2268,'TLACHICHILCO',30),(2269,'TLACOJALPAN',30),(2270,'TLACOLULAN',30),(2271,'TLACOTALPAN',30),(2272,'TLACOTEPEC DE MEJÍA',30),(2273,'TLALIXCOYAN',30),(2274,'TLALNELHUAYOCAN',30),(2275,'TLALTETELA ',30),(2276,'TLAPACOYAN',30),(2277,'TLAQUILPA',30),(2278,'TLILAPAN',30),(2279,'TOMATLÁN',30),(2280,'TONAYÁN',30),(2281,'TOTUTLA',30),(2282,'TRES VALLES',30),(2283,'TUXPAN',30),(2284,'TUXTILLA',30),(2285,'ÚRSULO GALVÁN',30),(2286,'UXPANAPA',30),(2287,'VEGA DE ALATORRE',30),(2288,'VERACRUZ',30),(2289,'VIGAS DE RAMÍREZ, LAS',30),(2290,'VILLA ALDAMA',30),(2291,'XALAPA ',30),(2292,'XICO ',30),(2293,'XOXOCOTLA',30),(2294,'YANGA',30),(2295,'YECUATLA',30),(2296,'ZACUALPAN',30),(2297,'ZARAGOZA',30),(2298,'ZENTLA',30),(2299,'ZONGOLICA',30),(2300,'ZONTECOMATLÁN',30),(2301,'ZOZOCOLCO DE HIDALGO',30),(2302,'ABALÁ',31),(2303,'ACANCEH',31),(2304,'AKIL',31),(2305,'BACA',31),(2306,'BOKOBÁ',31),(2307,'BUCTZOTZ',31),(2308,'CACALCHÉN',31),(2309,'CALOTMUL',31),(2310,'CANSAHCAB',31),(2311,'CANTAMAYEC',31),(2312,'CELESTÚN',31),(2313,'CENOTILLO',31),(2314,'CONKAL',31),(2315,'CUNCUNUL',31),(2316,'CUZAMÁ',31),(2317,'CHACSINKÍN',31),(2318,'CHANKOM',31),(2319,'CHAPAB',31),(2320,'CHEMAX',31),(2321,'CHICXULUB PUEBLO',31),(2322,'CHICHIMILÁ',31),(2323,'CHIKINDZONOT',31),(2324,'CHOCHOLÁ',31),(2325,'CHUMAYEL',31),(2326,'DZAN',31),(2327,'DZEMUL',31),(2328,'DZIDZANTÚN',31),(2329,'DZILAM DE BRAVO',31),(2330,'DZILAM GONZÁLEZ',31),(2331,'DZITÁS',31),(2332,'DZONCAUICH',31),(2333,'ESPITA',31),(2334,'HALACHÓ',31),(2335,'HOCABÁ',31),(2336,'HOCTÚN',31),(2337,'HOMÚN',31),(2338,'HUHÍ',31),(2339,'HUNUCMÁ',31),(2340,'IXIL',31),(2341,'IZAMAL',31),(2342,'KANASÍN',31),(2343,'KANTUNIL',31),(2344,'KAUA',31),(2345,'KINCHIL',31),(2346,'KOPOMÁ',31),(2347,'MAMA',31),(2348,'MANÍ',31),(2349,'MAXCANÚ',31),(2350,'MAYAPÁN',31),(2351,'MÉRIDA',31),(2352,'MOCOCHÁ',31),(2353,'MOTUL',31),(2354,'MUNA',31),(2355,'MUXUPIP',31),(2356,'OPICHÉN',31),(2357,'OXKUTZCAB',31),(2358,'PANABÁ',31),(2359,'PETO',31),(2360,'PROGRESO',31),(2361,'QUINTANA ROO ROO',31),(2362,'RÍO LAGARTOS',31),(2363,'SACALUM',31),(2364,'SAMAHIL',31),(2365,'SANAHCAT',31),(2366,'SAN FELIPE',31),(2367,'SANTA ELENA',31),(2368,'SEYÉ',31),(2369,'SINANCHÉ',31),(2370,'SOTUTA',31),(2371,'SUCILÁ',31),(2372,'SUDZAL',31),(2373,'SUMA',31),(2374,'TAHDZIÚ',31),(2375,'TAHMEK',31),(2376,'TEABO',31),(2377,'TECOH',31),(2378,'TEKAL DE VENEGAS',31),(2379,'TEKANTÓ',31),(2380,'TEKAX',31),(2381,'TEKIT',31),(2382,'TEKOM',31),(2383,'TELCHAC PUEBLO',31),(2384,'TELCHAC PUERTO',31),(2385,'TEMAX',31),(2386,'TEMOZÓN',31),(2387,'TEPAKÁN',31),(2388,'TETIZ',31),(2389,'TEYA',31),(2390,'TICUL',31),(2391,'TIMUCUY',31),(2392,'TINÚM',31),(2393,'TIXCACALCUPUL',31),(2394,'TIXKOKOB',31),(2395,'TIXMÉHUAC',31),(2396,'TIXPÉHUAL',31),(2397,'TIZIMÍN',31),(2398,'TUNKÁS',31),(2399,'TZUCACAB',31),(2400,'UAYMA',31),(2401,'UCÚ',31),(2402,'UMÁN',31),(2403,'VALLADOLID',31),(2404,'XOCCHEL',31),(2405,'YAXCABÁ',31),(2406,'YAXKUKUL',31),(2407,'YOBAÍN',31),(2408,'APOZOL ',32),(2409,'APULCO ',32),(2410,'ATOLINGA ',32),(2411,'BENITO JUÁREZ ',32),(2412,'CALERA ',32),(2413,'CAÑITAS DE FEILPE PESCADOR ',32),(2414,'CONCEPCIÓN DEL ORO ',32),(2415,'CUAUHTÉMOC ',32),(2416,'CHALCHIHUITES ',32),(2417,'FRESNILLO ',32),(2418,'GENARO CODINA ',32),(2419,'GENERAL ENRIQUE ESTRADA ',32),(2420,'GENERAL FRANCISCO R. MURGUÍA ',32),(2421,'GENERAL PÁNFILO NATERA ',32),(2422,'GUADALUPE ',32),(2423,'HUANUSCO ',32),(2424,'JALPA ',32),(2425,'JEREZ ',32),(2426,'JIMÉNEZ DEL TEUL ',32),(2427,'SANTA MARÍA DE LA PAZ ',32),(2428,'JUAN ALDAMA ',32),(2429,'JUCHIPILA ',32),(2430,'LORETO ',32),(2431,'LUIS MOYA ',32),(2432,'MAZAPIL ',32),(2433,'MELCHOR OCAMPO ',32),(2434,'MEZQUITAL DEL ORO ',32),(2435,'MIGUEL AUZA ',32),(2436,'MOMAX ',32),(2437,'MONTE ESCOBEDO ',32),(2438,'MORELOS ',32),(2439,'MOYAHUA DE ESTRADA ',32),(2440,'NOCHISTLÁN DE MEJÍA ',32),(2441,'NORIA DE ÁNGELES ',32),(2442,'OJOCALIENTE ',32),(2443,'PÁNUCO ',32),(2444,'PINOS ',32),(2445,'PLATEADO DE JOAQUÍN AMARO, EL ',32),(2446,'RÍO GRANDE ',32),(2447,'SAÍN ALTO',32),(2448,'SALVADOR, EL',32),(2449,'SOMBRERETE',32),(2450,'SUSTICACÁN',32),(2451,'TABASCO',32),(2452,'TEPECHITLÁN',32),(2453,'TEPETONGO',32),(2454,'TEUL DE GONZÁLEZ ORTEGA',32),(2455,'TLALTENANGO DE SÁNCHEZ ROMÁN',32),(2456,'TRANCOSO',32),(2457,'TRINIDAD GARCÍA DE LA CADENA',32),(2458,'VALPARAÍSO',32),(2459,'VETAGRANDE',32),(2460,'VILLA DE COS',32),(2461,'VILLA GARCÍA',32),(2462,'VILLA GONZÁLEZ ORTEGA',32),(2463,'VILLA HIDALGO',32),(2464,'VILLANUEVA',32),(2465,'ZACATECAS',32);
/*!40000 ALTER TABLE `municipios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seleccion_carrera`
--

DROP TABLE IF EXISTS `seleccion_carrera`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `seleccion_carrera` (
  `id_seleccion_carrera` int NOT NULL AUTO_INCREMENT,
  `primera_opcioncarrera` varchar(45) DEFAULT NULL,
  `eleccion_tipoinstitucion` varchar(45) DEFAULT NULL,
  `primera_eleccion` varchar(45) DEFAULT NULL,
  `seleccion_carreracol` varchar(45) DEFAULT NULL,
  `primera_eleccionnombre` varchar(45) DEFAULT NULL,
  `razon_eleccioninstitucion` varchar(45) DEFAULT NULL,
  `razon_eleccioncarrera` varchar(45) DEFAULT NULL,
  `matricula` varchar(10) NOT NULL,
  PRIMARY KEY (`id_seleccion_carrera`),
  KEY `fk_seleccionCarrera_alumno1` (`matricula`),
  CONSTRAINT `fk_seleccionCarrera_alumno1` FOREIGN KEY (`matricula`) REFERENCES `alumno` (`matricula`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seleccion_carrera`
--

LOCK TABLES `seleccion_carrera` WRITE;
/*!40000 ALTER TABLE `seleccion_carrera` DISABLE KEYS */;
/*!40000 ALTER TABLE `seleccion_carrera` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-07-20 10:48:59
