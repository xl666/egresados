#!/bin/bash

sleep 15

su -c 'python3 -u /monitor/monitor.py &' permitido

su -c 'python3 -u manage.py makemigrations' permitido
su -c 'python3 -u manage.py migrate' permitido
su -c 'gunicorn --bind :8000 control_egresados.wsgi:application --reload' permitido