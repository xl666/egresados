from django.contrib import admin

from .models import *

admin.site.register(Alumno)
admin.site.register(ContinuacionEstudios)
admin.site.register(DesempenioRecomendaciones)
admin.site.register(EmpleoInmediato)
admin.site.register(Empresa)
admin.site.register(Estados)
admin.site.register(Licenciatura)
admin.site.register(Municipios)
admin.site.register(SeleccionCarrera)



# Register your models here.
