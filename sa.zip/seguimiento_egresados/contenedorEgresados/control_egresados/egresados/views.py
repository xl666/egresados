from django.http import HttpResponse
from django.shortcuts import render, redirect, HttpResponse, Http404, get_object_or_404
from django.views.generic import ListView, CreateView, UpdateView
from django.template.loader import render_to_string
from django.contrib import messages
from control_egresados import settings
from django.db import transaction 
from egresados.forms import *


def bienvenida(request):
	if request.method == 'GET':
		return render(request, 'bienvenida.html')

	if request.method == 'POST':
		return redirect("inicio")

def inicio(request):
	if request.method == 'GET':
		return render(request, 'inicio.html')

	if request.method == 'POST':
		matricula = request.POST['matricula']
		request.session['matricula'] = matricula
		alumno = Alumno.objects.filter(matricula=matricula).first()
		if alumno:
			print("ALUMNO")
			print(alumno)
			return redirect("egresados:edit_alumno")
		else:
			return redirect("egresados:create_alumno")


def salir(request):
	try:
		del request.session['matricula']
		return render(request, 'inicio.html')
	except KeyError:
		pass
	return HttpResponse("No pudo finalizar la sesión")


def seleccion_carrera(request):
	if request.method == 'GET':
		matricula = request.session['matricula']
		seleccion = SeleccionCarrera.objects.filter(matricula=matricula).first()
		if seleccion:
			return redirect("egresados:edit_seleccion_carrera")
		else:
			return redirect("egresados:create_seleccion_carrera")

def detalle_alumno(request):
	if request.method == 'GET':
		matricula = request.session['matricula']
		alumno = Alumno.objects.filter(matricula=matricula).first()
		if alumno:
			return redirect("egresados:edit_alumno")
		else:
			return redirect("egresados:create_alumno")

def licenciatura(request):
	if request.method == 'GET':
		matricula = request.session['matricula']
		lic = Licenciatura.objects.filter(matricula=matricula).first()
		if lic:
			return redirect("egresados:edit_licenciatura")
		else:
			return redirect("egresados:create_licenciatura")

def continuacion_estudios(request):
	if request.method == 'GET':
		matricula = request.session['matricula']
		continuacion_estudios = ContinuacionEstudios.objects.filter(matricula = matricula).first()
		if continuacion_estudios:
			return redirect("egresados:edit_continuacion_estudios")
		else: 
			return redirect("egresados:create_continuacion_estudios")

def empleo_inmediato(request):
	if request.method == 'GET':
		matricula = request.session['matricula']
		empleo = EmpleoInmediato.objects.filter(matricula=matricula).first()
		if empleo:
			return redirect("egresados:edit_empleo_inmediato")
		else:
			return redirect("egresados:create_empleo_inmediato")

def empleo_actual(request):
	if request.method == 'GET':
		matricula = request.session['matricula']
		empresa = Empresa.objects.filter(matricula=matricula).first()
		if empresa:
			return redirect("egresados:edit_empleo_actual")
		else:
			return redirect("egresados:create_empleo_actual")

def recomendaciones(request):
	if request.method == 'GET':
		matricula = request.session['matricula']
		recomendaciones = DesempenioRecomendaciones.objects.filter(matricula = matricula).first()
		if recomendaciones:
			return redirect("egresados:edit_recomendaciones")
		else: 
			return redirect("egresados:create_recomendaciones")


def edit_alumno(request):
  matricula = request.session['matricula']
  alumno = Alumno.objects.filter(matricula=matricula).first()
  if request.method == 'GET':
  	form = AlumnoForm(instance=alumno)
  	form.fields['matricula'].widget.attrs['maxlength'] = '9'
  	form.fields['codigo_postal'].widget.attrs['maxlength'] = '5'
  	return render(request, 'editAlumno.html', {'form':form, 'alumno':alumno})

  if request.method == 'POST':
  	form = AlumnoForm(data=request.POST, instance=alumno)
  	form.fields['matricula'].widget.attrs['maxlength'] = '9'
  	form.fields['codigo_postal'].widget.attrs['maxlength'] = '5'
  	if form.is_valid():
  		form.save()
  		return render(request, 'editAlumno.html', {'form':form, 'alumno':alumno})
  		messages.success(request, "Información modificada correctamente")
  	else:
  		return render(request, 'editAlumno.html', {'form':form, 'alumno':alumno})
  		messages.error(request, "No se pudo hacer la modificación, intente más tarde")


def create_alumno(request):
	if request.method == 'GET':
		form = AlumnoForm()
		return render(request, 'createAlumno.html', {'form':form})

	if request.method == 'POST':
		form = AlumnoForm(data=request.POST)
		form.fields['matricula'].widget.attrs['maxlength'] = '9'
		form.fields['codigo_postal'].widget.attrs['maxlength'] = '5'
		if form.is_valid():
			form.save()
			messages.success(request, "Registro exitoso")
			return redirect("egresados:edit_alumno")
		else:
			return render(request, 'createAlumno.html', {'form':form})
			messages.error(request, "Registro no exitoso, intente más tarde")


def cargar_municipios(request):
	print("CARGAR MUNICIPIOS")
	estado = request.GET.get('id_estado')
	municipios = Municipios.objects.filter(id_estado=estado).order_by('nombre_municipio')
	return render(request, 'municipios.html', {'municipios' : municipios})

#def getdetails(request):
    #country_name = request.POST['country_name']
 #   estado_name = request.GET['est']
  #  print ("ajax country_name ", estado_name)
#
 #   result_set = []
  #  all_municipios = []
   # answer = str(estado_name[1:-1])
    #selected_estado = Estado.objects.get(name=answer)
    #print ("selected country name ", selected_estado)
    #all_municipios = selected_estado.municipios_set.all()
    #for municipios in all_municipios:
     #   print ("city name", municipios.nombre_municipio)
      #  result_set.append({'name': municipios.nombre_municipio})
    # return HttpResponse(simplejson.dumps(result_set), mimetype='application/json',     content_type='application/json')



def edit_seleccion_carrera(request):
  matricula = request.session['matricula']
  seleccion = SeleccionCarrera.objects.filter(matricula=matricula).first()
  if request.method == 'GET':
  	form = SeleccionCarreraForm(instance=seleccion)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	return render(request, 'editSeleccionCarrera.html', {'form':form, 'seleccion':seleccion})

  if request.method == 'POST':
  	form = SeleccionCarreraForm(data=request.POST, instance=seleccion)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	if form.is_valid():
  		form.save()
  		return render(request, 'editSeleccionCarrera.html', {'form':form, 'seleccion':seleccion})
  		messages.success(request, "Información modificada correctamente")
  	else:
  		return render(request, 'editSeleccionCarrera.html', {'form':form, 'seleccion':seleccion})
  		messages.error(request, "No se pudo hacer la modificación, intente más tarde")

@transaction.atomic
def create_seleccion_carrera(request):
	if request.method == 'GET':
		form = SeleccionCarreraForm()
		form.fields['matricula'].widget = forms.HiddenInput()
		return render(request, 'createSeleccionCarrera.html', {'form':form})

	if request.method == 'POST':
  		matricula = request.session['matricula']
  		data = {'matricula': matricula}
  		request_post = request.POST.copy()
  		request_post.update(data)
  		form = SeleccionCarreraForm(data=request_post)
  		print(form.errors)
  		if form.is_valid():
  			form.save()
  			messages.success(request, "Registro exitoso")
  			return redirect("egresados:seleccion_carrera")
  		else:
  			form.fields['matricula'].widget = forms.HiddenInput()
  			messages.error(request, "Registro no exitoso, intente más tarde")
  			return render(request, 'createSeleccionCarrera.html', {'form':form})


def edit_licenciatura(request):
  matricula = request.session['matricula']
  licenciatura = Licenciatura.objects.filter(matricula=matricula).first()
  if request.method == 'GET':
  	form = LicenciaturaForm(instance=licenciatura)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	return render(request, 'editLicenciatura.html', {'form':form, 'licenciatura':licenciatura})

  if request.method == 'POST':
  	form = LicenciaturaForm(data=request.POST, instance=licenciatura)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	if form.is_valid():
  		form.save()
  		return render(request, 'editLicenciatura.html', {'form':form, 'licenciatura':licenciatura})
  		messages.success(request, "Información modificada correctamente")
  	else:
  		messages.error(request, "No se pudo hacer la modificación, intente más tarde")
  		return render(request, 'editLicenciatura.html', {'form':form, 'licenciatura':licenciatura})
  		

def create_licenciatura(request):
	if request.method == 'GET':
		form = LicenciaturaForm()
		form.fields['matricula'].widget = forms.HiddenInput()
		return render(request, 'createLicenciatura.html', {'form':form})

	if request.method == 'POST':
		matricula = request.session['matricula']
		data = {'matricula': matricula}
		request_post = request.POST.copy()
		request_post.update(data)
		form = LicenciaturaForm(data=request_post)
		form.fields['matricula'].widget = forms.HiddenInput()
		if form.is_valid():
			form.save()
			messages.success(request, "Registro exitoso")
			return redirect("egresados:edit_licenciatura")
		else:
			messages.error(request, "Registro no exitoso, intente más tarde")
			return render(request, 'createLicenciatura.html', {'form':form})
			


def edit_continuacion_estudios(request):
  matricula = request.session['matricula']
  continuacion = ContinuacionEstudios.objects.filter(matricula=matricula).first()
  if request.method == 'GET':
  	form = ContinuacionEstudiosForm(instance=continuacion)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	return render(request, 'editContinuacionEstudios.html', {'form':form, 'continuacion':continuacion})

  if request.method == 'POST':
  	form = ContinuacionEstudiosForm(data=request.POST, instance=continuacion)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	if form.is_valid():
  		form.save()
  		return render(request, 'editContinuacionEstudios.html', {'form':form, 'continuacion':continuacion})
  		messages.success(request, "Información modificada correctamente")
  	else:
  		messages.error(request, "No se pudo hacer la modificación, intente más tarde")
  		return render(request, 'editContinuacionEstudios.html', {'form':form, 'continuacion':continuacion})
  		

def create_continuacion_estudios(request):
	if request.method == 'GET':
		form = ContinuacionEstudiosForm()
		form.fields['matricula'].widget = forms.HiddenInput()
		return render(request, 'createContinuacionEstudios.html', {'form':form})

	if request.method == 'POST':
		matricula = request.session['matricula']
		data = {'matricula': matricula}
		request_post = request.POST.copy()
		request_post.update(data)
		form = ContinuacionEstudiosForm(data=request_post)
		form.fields['matricula'].widget = forms.HiddenInput()
		if form.is_valid():
			form.save()
			messages.success(request, "Registro exitoso")
			return redirect("egresados:edit_continuacion_estudios")
		else:
			messages.error(request, "Registro no exitoso, intente más tarde")
			return render(request, 'createContinuacionEstudios.html', {'form':form})
			


def edit_empleo_inmediato(request):
  matricula = request.session['matricula']
  empleo = EmpleoInmediato.objects.filter(matricula=matricula).first()
  if request.method == 'GET':
  	form = EmpleoInmediatoForm(instance=empleo)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	return render(request, 'editEmpleoInmediato.html', {'form':form, 'empleo':empleo})

  if request.method == 'POST':
  	form = EmpleoInmediatoForm(data=request.POST, instance=empleo)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	if form.is_valid():
  		form.save()
  		return render(request, 'editEmpleoInmediato.html', {'form':form, 'empleo':empleo})
  		messages.success(request, "Información modificada correctamente")
  	else:
  		messages.error(request, "No se pudo hacer la modificación, intente más tarde")
  		return render(request, 'editEmpleoInmediato.html', {'form':form, 'empleo':empleo})
  		

def create_empleo_inmediato(request):
	if request.method == 'GET':
		form = EmpleoInmediatoForm()
		form.fields['matricula'].widget = forms.HiddenInput()
		return render(request, 'createEmpleoInmediato.html', {'form':form})

	if request.method == 'POST':
		matricula = request.session['matricula']
		data = {'matricula': matricula}
		request_post = request.POST.copy()
		request_post.update(data)
		form = EmpleoInmediatoForm(data=request_post)
		form.fields['matricula'].widget = forms.HiddenInput()
		if form.is_valid():
			form.save()
			messages.success(request, "Registro exitoso")
			return redirect("egresados:edit_empleo_inmediato")
		else:
			messages.error(request, "Registro no exitoso, intente más tarde")
			return render(request, 'createEmpleoInmediato.html', {'form':form})
			


def edit_empleo_actual(request):
  matricula = request.session['matricula']
  empresa = Empresa.objects.filter(matricula=matricula).first()
  if request.method == 'GET':
  	form = EmpresaForm(instance=empresa)
  	form.fields['codigo_postal'].widget.attrs['maxlength'] = '5'
  	form.fields['matricula'].widget = forms.HiddenInput()
  	return render(request, 'editEmpleoActual.html', {'form':form, 'empresa':empresa})

  if request.method == 'POST':
  	form = EmpresaForm(data=request.POST, instance=empresa)
  	form.fields['codigo_postal'].widget.attrs['maxlength'] = '5'
  	if form.is_valid():
  		form.save()
  		return render(request, 'editEmpleoActual.html', {'form':form, 'empresa':empresa})
  		messages.success(request, "Información modificada correctamente")
  	else:
  		messages.error(request, "No se pudo hacer la modificación, intente más tarde")
  		return render(request, 'editEmpleoActual.html', {'form':form, 'empresa':empresa})
  		

def create_empleo_actual(request):
	if request.method == 'GET':
		form = EmpresaForm()
		form.fields['matricula'].widget = forms.HiddenInput()
		return render(request, 'createEmpleoActual.html', {'form':form})

	if request.method == 'POST':
		matricula = request.session['matricula']
		data = {'matricula': matricula}
		request_post = request.POST.copy()
		request_post.update(data)
		form = EmpresaForm(data=request_post)
		form.fields['matricula'].widget = forms.HiddenInput()
		if form.is_valid():
			form.save()
			messages.success(request, "Registro exitoso")
			return redirect("egresados:edit_empleo_actual")
		else:
			messages.error(request, "Registro no exitoso, intente más tarde")
			return render(request, 'createEmpleoActual.html', {'form':form})
			


def edit_recomendaciones(request):
  matricula = request.session['matricula']
  recomendaciones = DesempenioRecomendaciones.objects.filter(matricula=matricula).first()
  if request.method == 'GET':
  	form = DesempenioRecomendacionesForm(instance=recomendaciones)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	return render(request, 'editRecomendaciones.html', {'form':form, 'recomendaciones':recomendaciones})

  if request.method == 'POST':
  	form = DesempenioRecomendacionesForm(data=request.POST, instance=recomendaciones)
  	form.fields['matricula'].widget = forms.HiddenInput()
  	if form.is_valid():
  		form.save()
  		return render(request, 'editRecomendaciones.html', {'form':form, 'recomendaciones':recomendaciones})
  		messages.success(request, "Información modificada correctamente")
  	else:
  		messages.error(request, "No se pudo hacer la modificación, intente más tarde")
  		return render(request, 'editRecomendaciones.html', {'form':form, 'recomendaciones':recomendaciones})
  		

def create_recomendaciones(request):
	if request.method == 'GET':
		form = DesempenioRecomendacionesForm()
		form.fields['matricula'].widget = forms.HiddenInput()
		return render(request, 'createRecomendaciones.html', {'form':form})

	if request.method == 'POST':
		matricula = request.session['matricula']
		data = {'matricula': matricula}
		request_post = request.POST.copy()
		request_post.update(data)
		form = DesempenioRecomendacionesForm(data=request_post)
		form.fields['matricula'].widget = forms.HiddenInput()
		if form.is_valid():
			form.save()
			messages.success(request, "Registro exitoso")
			return redirect("egresados:edit_recomendaciones")
		else:
			messages.error(request, "Registro no exitoso, intente más tarde")
			return render(request, 'createRecomendaciones.html', {'form':form})
			
