from django.apps import AppConfig


class EgresadosConfig(AppConfig):
    name = 'egresados'
