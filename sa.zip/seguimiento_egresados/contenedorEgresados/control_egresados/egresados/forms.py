from django import forms
from .models import *
from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from django.forms import ModelForm, PasswordInput
from django.core.validators import FileExtensionValidator



class AlumnoForm(ModelForm):
	class Meta:
		model = Alumno
		fields = ('matricula', 'nombre', 'apellido_paterno', 'apellido_materno', 'genero', 
		'fecha_nacimiento', 'estado_civil', 'correo', 'correo_uv', 'celular', 'twitter', 
		'facebook', 'calle', 'colonia', 'numero', 'codigo_postal', 'id_estado', 'id_municipio')
		labels = {
            'matricula': 'Matrícula',
            'nombre': 'Nombre',
            'apellido_paterno': 'Apellido paterno', 
            'apellido_materno': 'Apellido materno', 
            'genero': 'Género',
            'fecha_nacimiento': 'Fecha de nacimiento YYYY-MM-DD',
            'estado_civil': 'Estado civil', 
            'correo': 'Correo electronico', 
            'correo_uv': 'Correo UV', 
            'celular': 'Celular', 
            'twitter': 'Twitter', 
            'facebook': 'Facebook', 
            'calle': 'Calle', 
            'colonia': 'Colonia', 
            'numero': 'Número', 
            'codigo_postal': 'CP', 
        	'id_estado': 'Estado', 
        	'id_municipio': 'Municipio',
        }	
	widgets={
            'id_estado': forms.Select(attrs={'id':'id_estado', 'name': 'id_estado'}),
            'id_municipio': forms.Select(attrs={'id':'id_municipio', 'name': 'id_municipio'}),
        }


        
    



class SeleccionCarreraForm(ModelForm):
 	class Meta:
 		model = SeleccionCarrera
 		fields = ('matricula', 'primera_opcioncarrera', 'eleccion_tipoinstitucion', 'primera_eleccion', 'seleccion_carreracol', 
 			'primera_eleccionnombre', 'razon_eleccioninstitucion')
 		labels = {
 			'matricula': 'Matrícula',
 			'primera_opcioncarrera': '¿La institución en que usted cursó sus estudios de licenciatura fue la primera que eligió?',
 			'eleccion_tipoinstitucion': 'Tipo institución que había elegido',
 			'primera_eleccion': '¿La carrera que usted cursó fue su primera elección?',
 			'seleccion_carreracol': 'En caso de haber Escrito "No" en la tercera pregunta, ¿Qué carrera había elegido?',
 			'primera_eleccionnombre': '¿Cuál fue para usted la razón más importante en la elección de la institución?', 
 			'razon_eleccioninstitucion': '¿Cuál fue para usted la razón más importante en la elección de la carrera?',
 			
 		}



class LicenciaturaForm(ModelForm):
	class Meta:
		model = Licenciatura
		fields = ('matricula', 'nombre_campus', 'nombre_carrera', 'anio_pestudios', 'anio_inicio', 'anio_fin', 'org_ss',
			'fecha_inicioss', 'fecha_finss', 'titulado', 'promedio_final', 'tipo_inscripcion')
		labels = {
			'matricula': 'Matrícula',
			'nombre_campus': 'Nombre del campus',
			'nombre_carrera': 'Nombre de la carrera',
			'anio_pestudios': 'Generación',
			'anio_inicio': 'Año de inicio',
			'anio_fin': 'Año de finalización',
			'org_ss': 'Organización donde realizó el servicio social',
			'fecha_inicioss': 'Fecha de inicio del servicio social',
			'fecha_finss': 'Fecha de finalización del servicio social',
			'titulado': '¿Titulado?',
			'promedio_final': 'Promedio final',
			'tipo_inscripcion': 'Tipo de inscripción',
		}

class ContinuacionEstudiosForm(ModelForm):
	class Meta:
		model = ContinuacionEstudios
		fields = ('matricula', 'tipoestudio_continuacion', 'institucion', 'nombre_programa', 'anio_inicio', 'anio_fin')
		labels = {
			'matricula': 'Matrícula',
			'tipoestudio_continuacion': '¿Una vez que concluyó su licenciatura optó por otro tipo de estudios? ¿Cuál fue este tipo de estudio?',
			'institucion': 'Nombre de la institución',
			'nombre_programa': 'Nombre del programa',
			'anio_inicio': 'Año de inicio',
			'anio_fin': 'Año de finalización',
		}

class EmpleoInmediatoForm(ModelForm):
	class Meta:
		model = EmpleoInmediato
		fields = ('matricula', 'trabajo_ultimoanio', 'coincidencia_trabajoest', 'trabajo_finlic', 'busqueda_trab_finlic',
			'tiempo_primerempleo', 'razon_dificultad_primerempleo', 'medio_conseguir_empleo',
			'requisito_formal_empleo', 'puesto_empleo_inmediato', 'tamano_empresa_inmediata', 'regimen_juridico',
			'ingreso_mensual_neto_inicio', 'horas_laboral_semanales', 'duracion_trabajo', 'sector_economico',
			'razon_nobusqueda_empleo')
		labels = {
			'matricula': 'Matrícula',
			'trabajo_ultimoanio': '¿Trabajó usted durante el último año de sus estudios de licenciatura?',
			'coincidencia_trabajoest': '¿En qué medida coincidía su trabajo con sus estudios de licenciatura?',
			'trabajo_finlic': '¿Tenía usted empleo al concluir sus estudios de licenciatura? (Recuerde que por estudios concluidos entendemos haber cubierto el total de créditos de cursos)',
			'busqueda_trab_finlic': '¿Al concluir sus estudios buscó Ud. activamente trabajo? (Nos interesa su respuesta, aunque ya estuviese trabajando)',
			'tiempo_primerempleo': 'Indique el tiempo que le llevó conseguir  el primer empleo, una vez que concluyó sus estudios de licenciatura. (Nos referimos al empleo cuya duración mínima fue de tres meses)',
			'razon_dificultad_primerempleo': '¿A qué atribuye la demora y/o dificultades para conseguir empleo al concluir sus estudios? (Solo si tuvo demoras o dificultades)',
			'medio_conseguir_empleo':'Señale el principal medio a través del cual encontró trabajo al concluir sus estudios',
			'requisito_formal_empleo': '¿Cuál fue el requisito formal de mayor peso para conseguir el trabajo, una vez que concluyó sus estudios y lo buscó?',
			'puesto_empleo_inmediato': 'El puesto inicial que ocupó era',
			'tamano_empresa_inmediata': 'El tamaño de la empresa/institución era',
			'regimen_juridico': 'El régimen jurídico de la empresa/institución en que trabajaba era',
			'ingreso_mensual_neto_inicio': 'Indique su ingreso mensual neto al inicio (incluyendo bonos y prestaciones)',
			'horas_laboral_semanales': 'Número de horas en promedio que laboraba a la semana',
			'duracion_trabajo': 'Su duración en el trabajo (en meses) fue',
			'sector_economico': 'El sector económico (rama) de la empresa o institución en que trabajaba era',
			'razon_nobusqueda_empleo': 'SÓLO PARA EGRESADOS QUE NO TRABAJARON EN UN EMPLEO DE MÁS DE TRES MESES AL TERMINAR LA LICENCIATURA Señale la razón principal por la que no tenía trabajo',
		}

class EmpresaForm(ModelForm):
	class Meta:
		model = Empresa
		fields = ('matricula', 'nombre_empresa', 'calle_empresa', 'colonia_empresa', 'num_empresa', 'codigo_postal',
			'id_estado', 'id_municipio', 'departamento', 'puesto', 'tipo_contratacion', 'regimen_juridico',
			'ingresomensual_neto', 'horas_laborales', 'fecha_inicio', 'medida_coincidencia_labestudios',
			'sector_economico', 'otro_empleo')
		labels = {
		'matricula': 'Matrícula',
		'nombre_empresa' : 'Nombre de la empresa/institución en que trabaja',
		'calle_empresa': 'Calle',
		'colonia_empresa': 'Colonia',
		'num_empresa': 'Número',
		'codigo_postal': 'CP',
		'id_estado': 'Estado',
		'id_municipio': 'Municipio', 
		'departamento': 'Señale la principal actividad que usted desempeña', 
		'puesto': 'El puesto que ocupa actualmente es', 
		'tipo_contratacion': 'Señale el tipo de contratación que usted tiene',
		'regimen_juridico': 'Señale el régimen jurídico de la empresa/institución en que trabaja',
		'ingresomensual_neto': 'Indique su ingreso mensual neto actual (incluyendo bonos y prestaciones)',
		'horas_laborales': 'Número de horas en promedio que labora a la semana',
		'fecha_inicio': 'Año de inicio',
		'medida_coincidencia_labestudios': '¿En qué medida coincide su actividad laboral con los estudios de licenciatura?',
		'sector_economico': 'Señale el sector económico (rama) de la empresa o institución en que trabaja',
		'otro_empleo': '¿Además de su empleo principal tiene ud. otro empleo?',
		}

class DesempenioRecomendacionesForm(ModelForm):
	class Meta:
		model = DesempenioRecomendaciones
		fields = ('matricula', 'nivel_satisfaccion', 'grado_exigencia', 'nivel_formacion', 'modificaciones_planest',
			'opinion_orgainst')
		labels = {
		'matricula': 'Matrícula',
		'nivel_satisfaccion': '¿Qué tan satisfecho está usted con los conocimientos adquiridos durante sus estudios de licenciatura?',
		'grado_exigencia': 'De acuerdo con su experiencia laboral actual y la(s) actividad (es) que desarrolla, indíquenos, por favor, cuál es el grado de exigencia que enfrenta en aspectos como: Conocimientos generales de la disciplina, Conocimiento de lenguas extranjeras, etc',
		'nivel_formacion': '¿En qué medida la formación de licenciatura lo preparó para el campo laboral?',
		'modificaciones_planest': '¿Qué modificaciones sugeriría al plan de estudios que usted cursó?',
		'opinion_orgainst': '¿Cuál sería su opinión acerca de la organización institucional en donde curso la licenciatura?',
		}
