# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from django.core.validators import RegexValidator



GENEROS = (
    ('', 'Seleccione género'),
    ('M', 'Masculino'), #First one is the value of select option and second is the displayed value in option
    ('F', 'Femenino'),
    )
ESTADO_CIVIL = (
    ('', 'Seleccione...'),
    ('Soltero/a', 'Soltero/a'), #First one is the value of select option and second is the displayed value in option
    ('Casado/a', 'Casado/a'),
    ('Divorciado/a', 'Divorciado/a'),
    ('Viudo/a', 'Viudo/a')

    )
TIPO_INSTITUCION = (
    ('', 'Seleccione el tipo de institución'),
    ('Universidad Pública', 'Universidad Pública'), #First one is the value of select option and second is the displayed value in option
    ('Universidad Privada', 'Universidad Privada'),
    ('Instituto Tecnológico y/o Politécnico Público', 'Instituto Tecnológico y/o Politécnico Público'),
    ('Instituto Tecnológico Privado', 'Instituto Tecnológico Privado'),
    ('Otro', 'Otro')
    )
TITULADO_CHOICES = (
    ('', 'Seleccione...'),
    ('Sí', 'Titulado'),
    ('No', 'No titulado'),
    ('En proceso', 'En proceso')
)

PRIMERAOPCION_CHOICES = (
    ('', 'Seleccione...'),
    ('Sí', 'Sí'),
    ('No', 'No'),
)

TIPOINSCRIPCION = (
    ('', 'Seleccione el tipo de inscripción'),
    ('Temporanea', 'Temporanea'),
    ('Extemporanea', 'Extemporanea')
)

TIPO_CONTINUACION_ESTUDIOS = (
    ('', 'Seleccione el tipo de continuación de estudios...'),
    ('Cursos cortos ', 'Cursos cortos'),
    ('Diplomado ', 'Diplomado'),
    ('Especialización', 'Especialización'),
    ('Maestría', 'Maestría'),
    ('Doctorado', 'Doctorado'),
    ('Otro', 'Otro')
)

TIPO_INSTITUCION_CONTINUACION = (
    ('', 'Seleccione el tipo de institución'),
    ('Pública ', 'Pública'), #First one is the value of select option and second is the displayed value in option
    ('Privada',  'Privada'),
    ('Otro', 'Otro')
)

MEDIDA_COINCIDENCIA_ESTUDIOS = (
    ('', 'Seleccione...'),
    ('Nula coincidencia', 'Nula coincidencia'),
    ('Baja coincidencia', 'Baja coincidencia'),
    ('Mediana coincidencia', 'Mediana coincidencia'),
    ('Alta coincidencia', 'Alta coincidencia')
)

TIEMPO_CONSEGUIR_EMPLEO = (
    ('', 'Seleccione...'),
    ('Menos de seis meses', 'Menos de seis meses'),
    ('De seis meses a un año','De seis meses a un año'),
    ('De 1 año 1 día a 2 años', 'De 1 año 1 día a 2 años'),
    ('Más de 2 años', 'Más de 2 años'),
    ('No encontré y seguí en el mismo empleo', 'No encontré y seguí en el mismo empleo'),
    ('No encontré empleo, quedé desocupado', 'No encontré empleo, quedé desocupado'),
    ('Otro', 'Otro')
    )

DEMORA_EMPLEO = (
    ('', 'Seleccione...'),
    ('Escasa experiencia laboral', 'Escasa experiencia laboral'),
    ('La carrera es poco conocida', 'La carrera es poco conocida'),
    ('Su situación personal se lo dificultó', 'Su situación personal se lo dificultó'),
    ('Tenía ofertas de trabajo poco atractivas', 'Tenía ofertas de trabajo poco atractivas'),
    ('Otro ', 'Otro')
    )

MEDIO_EMPLEO = (
    ('', 'Seleccione...'),
    ('Bolsa de trabajo', 'Bolsa de trabajo'),
    ('Anuncio en el periódico', 'Anuncio en el periódico'),
    ('Invitación expresa de una empresa', 'Invitación expresa de una empresa'),
    ('Recomendación de amigos de la licenciatura', 'Recomendación de amigos de la licenciatura'),
    ('Recomendación de un profesor', 'Recomendación de un profesor'),
    ('Recomendación de un amigo o familiar', 'Recomendación de un amigo o familiar'),
    ('Relaciones hechas en empleos anteriores', 'Relaciones hechas en empleos anteriores'),
    ('Creación de un negocio de empresa, propios', 'Creación de empresa, propios'),
    ('Integración a un negocio familiar', 'Integración a un negocio familiar'),
    ('Servicio social', 'Servicio social'),
    ('Otro', 'Otro')
    )

REQUISITO_FORMAL_EMPLEO = (
    ('', 'Seleccione...'),
    ('Tener título de licenciatura', 'Tener título de licenciatura'),
    ('Aprobar los exámenes de selección', 'Aprobar los exámenes de selección'),
    ('Pasar una entrevista formal', 'Pasar una entrevista formal')
    )
PUESTO_INICIAL = (
    ('', 'Seleccione...'),
    ('Director general', 'Director general'),
    ('Dueño o socio de empresa, despacho, rancho', 'Dueño o socio de empresa, despacho, rancho'),
    ('Profesional independiente', 'Profesional independiente'),
    ('Gerente/Director de área', 'Gerente/Director de área'),
    ('Subgerente/Subdirector de área', 'Subgerente/Subdirector de área'),
    ('Jefe de departamento', 'Jefe de departamento'),
    ('Ejecutivo de Cuenta', 'Ejecutivo de Cuenta'),
    ('Jefe de oficina/sección/área', 'Jefe de oficina/sección/área'),
    ('Empleado profesional', 'Empleado profesional'),
    ('Supervisor', 'Supervisor'),
    ('Analista especializado/técnico', 'Analista especializado/técnico'),
    ('Profesional independiente', 'Profesional independiente'),
    ('Gerente/Director de área', 'Gerente/Director de área'),
    ('Subgerente/Subdirector de área', 'Subgerente/Subdirector de área'),
    ('Jefe de departamento', 'Jefe de departamento'),
    ('Ejecutivo de Cuenta', 'Ejecutivo de Cuenta'),
    ('Jefe de oficina/sección/área', 'Jefe de oficina/sección/área'),
    ('Empleado profesional', 'Empleado profesional'),
    ('Supervisor', 'Supervisor'),
    ('Analista especializado/técnico', 'Analista especializado/técnico'),
    ('Vendedor en establecimiento', 'Vendedor en establecimiento'), 
    ('Asistente', 'Asistente'),
    ('Ayudante', 'Ayudante'),
    ('Por cuenta propia no profesional', 'Por cuenta propia no profesional'),
    ('Empleado no profesional', 'Empleado no profesional'),
    ('Auxiliar', 'Auxiliar'),
    ('Otro', 'Otro')
    )

TAMANIO_EMPRESA_INMEDIATA = (
    ('', 'Seleccione...'),
    ('Hasta 15 empleados (Micro)', 'Hasta 15 empleados (Micro)'),
    ('Entre 16 y 100 empleados (Pequeña)', 'Entre 16 y 100 empleados (Pequeña)'),
    ('Entre 101 y 250 empleados (Mediana)', 'Entre 101 y 250 empleados (Mediana)'),
    ('Más de 251 empleados (Grande)', 'Más de 251 empleados (Grande)')
    )

REGIMEN_JURIDICO = (
    ('', 'Seleccione...'),
    ('Público', 'Público'),
    ('Privado', 'Privado')
    )

SECTOR_ECONOMICO = (
    ('', 'Seleccione...'),
    ('Agrícola-ganadero, silvícola,etc','Agrícola-ganadero, silvícola,etc'),
    ('Industria extractiva', 'Industria extractiva'),
    ('Industria de la transformación', 'Industria de la transformación'),
    ('Industria de la construcción', 'Industria de la construcción'),
    ('Comercio', 'Comercio'),
    ('Servicios bancarios, financieros y seguros', 'Servicios bancarios, financieros y seguros'),
    ('Transporte/comunicaciones', 'Transporte/comunicaciones'),
    ('Educación', 'Educación'),
    ('Servicios Profesionales y Técnicos', 'Servicios Profesionales y Técnicos'),
    ('Servicios de Salud', 'Servicios de Salud'),
    ('Servicios de Gobierno', 'Servicios de Gobierno'),
    ('Otro', 'Otro')
    )

RAZON_NO_EMPLEO = (
    ('', 'Seleccione...'),
    ('No encontré, pero seguí buscando', 'No encontré, pero seguí buscando'),
    ('No encontré y ya no busqué', 'No encontré y ya no busqué'),
    ('Estaba por incorporarme a un trabajo', 'Estaba por incorporarme a un trabajo'),
    ('Decidí continuar estudiando', 'Decidí continuar estudiando'),
    ('No necesitaba trabajar', 'No necesitaba trabajar'),
    ('No tuve trabajo por razones de salud', 'No tuve trabajo por razones de salud'),
    ('No tuve trabajo porque no lo busqué', 'No tuve trabajo porque no lo busqué'),
    ('Otro', 'Otro')
    )

DEPARTAMENTOS = (
    ('', 'Seleccione...'),
    ('Dirección', 'Dirección'),
    ('Coordinación', 'Coordinación'),
    ('Dirección de proyectos', 'Dirección de proyectos'),
    ('Coordinación de Proyectos', 'Coordinación de Proyectos'),
    ('Dirección de Obras', 'Dirección de Obras'),
    ('Coordinación de Obras', 'Coordinación de Obras'),
    ('Análisis de Sistemas', 'Análisis de Sistemas'),
    ('Planeación', 'Planeación'),
    ('Programación', 'Programación'),
    ('Evaluación', 'Evaluación'),
    ('Supervisión', 'Supervisión'),
    ('Mantenimiento', 'Mantenimiento'),
    ('Diagnóstico', 'Diagnóstico'),
    ('Investigación', 'Investigación'),
    ('Análisis Financiero', 'Análisis Financiero'),
    ('Capacitación', 'Capacitación'),
    ('Asesoría Especializada', 'Asesoría Especializada'),
    ('Consultoría', 'Consultoría'),
    ('Asesoría Técnica', 'Asesoría Técnica'),
    ('Comercialización', 'Comercialización'),
    ('Ventas', 'Ventas'),
    ('Desarrollo de Productos', 'Desarrollo de Productos'),
    ('Control de Calidad', 'Control de Calidad'),
    ('Atención a Pacientes', 'Atención a Pacientes'),
    ('Atención Psicológica', 'Atención Psicológica'),
    ('Trabajo Editorial', 'Trabajo Editorial'),
    ('Actividades de Organización', 'Actividades de Organización'),
    ('Actividades Administrativas', 'Actividades Administrativas'),
    ('Publicidad', 'Publicidad'),
    ('Atención a Clientes', 'Atención a Clientes'),
    ('Otro', 'Otro')
    )

TIPO_CONTRATACION = (
    ('', 'Seleccione...'),
    ('Por tiempo determinado', 'Por tiempo determinado'),
    ('Por obra determinada', 'Por obra determinada'),
    ('Por tiempo indeterminado', 'Por tiempo indeterminado'),
    ('Otro', 'Otro')
    )

NIVEL_SATISFACCION = (
    ('', 'Seleccione...'),
    ('Poco satisfecho', 'Poco satisfecho'),
    ('Satisfecho', 'Satisfecho'),
    ('Muy satisfecho', 'Muy satisfecho'),
    ('Totalmente satisfecho', 'Totalmente satisfecho')
    )

GRADO_EXIGENCIA = (
    ('', 'Seleccione...'),
    ('Ninguna exigencia', 'Ninguna exigencia '),
    ('Poca exigencia', 'Poca exigencia'),
    ('Moderada exigencia', 'Moderada exigencia'),
    ('Mucha exigencia', 'Mucha exigencia')
    )

NIVEL_FORMACION = (
    ('', 'Seleccione...'),
    ('Nada', 'Nada'),
    ('Poco', 'Poco'),
    ('En parte', 'En parte'),
    ('Mucho', 'Mucho')
    )

alphanumeric = RegexValidator(r'^[0-9a-zA-Z]*$', 'Only alphanumeric characters are allowed.')
just_number = RegexValidator(r'^\d+$', 'Only alphanumeric characters are allowed.')
just_letters = RegexValidator(r'^[a-zA-Z ]*$')



class Alumno(models.Model):
    matricula = models.CharField(primary_key=True, max_length=10, validators=[alphanumeric])
    nombre = models.CharField(max_length=45)
    apellido_paterno = models.CharField(max_length=45)
    genero = models.CharField(max_length=10, choices=GENEROS)
    fecha_nacimiento = models.DateField()
    estado_civil = models.CharField(max_length=45, choices=ESTADO_CIVIL)
    correo = models.CharField(max_length=45)
    correo_uv = models.CharField(max_length=45)
    celular = models.CharField(max_length=10, blank=True, null=True, validators=[just_number])
    twitter = models.CharField(max_length=45, blank=True, null=True)
    facebook = models.CharField(max_length=45, blank=True, null=True)
    calle = models.CharField(max_length=45, blank=True, null=True)
    colonia = models.CharField(max_length=45, blank=True, null=True)
    numero = models.CharField(max_length=45, blank=True, null=True)
    codigo_postal = models.CharField(max_length=15, blank=True, null=True, validators=[just_number])
    id_estado = models.ForeignKey('Estados', models.DO_NOTHING, db_column='id_estado', blank=True, null=True)
    id_municipio = models.ForeignKey('Municipios', models.DO_NOTHING, db_column='id_municipio', blank=True, null=True)
    apellido_materno = models.CharField(max_length=45)

    class Meta:
        managed = False
        db_table = 'alumno'


class AuthGroup(models.Model):
    name = models.CharField(unique=True, max_length=150)

    class Meta:
        managed = False
        db_table = 'auth_group'


class AuthGroupPermissions(models.Model):
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)
    permission = models.ForeignKey('AuthPermission', models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_group_permissions'
        unique_together = (('group', 'permission'),)


class AuthPermission(models.Model):
    name = models.CharField(max_length=255)
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING)
    codename = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'auth_permission'
        unique_together = (('content_type', 'codename'),)


class AuthUser(models.Model):
    password = models.CharField(max_length=128)
    last_login = models.DateTimeField(blank=True, null=True)
    is_superuser = models.IntegerField()
    username = models.CharField(unique=True, max_length=150)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=150)
    email = models.CharField(max_length=254)
    is_staff = models.IntegerField()
    is_active = models.IntegerField()
    date_joined = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'auth_user'


class AuthUserGroups(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    group = models.ForeignKey(AuthGroup, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_groups'
        unique_together = (('user', 'group'),)


class AuthUserUserPermissions(models.Model):
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)
    permission = models.ForeignKey(AuthPermission, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'auth_user_user_permissions'
        unique_together = (('user', 'permission'),)


class ContinuacionEstudios(models.Model):
    id_continuacion_estudios = models.IntegerField(primary_key=True)
    tipoestudio_continuacion = models.CharField(max_length=45, choices=TIPO_CONTINUACION_ESTUDIOS, null=True, blank=True)
    institucion = models.CharField(max_length=45, choices=TIPO_INSTITUCION_CONTINUACION, null=True, blank=True)
    nombre_programa = models.CharField(max_length=45, blank=True, null=True)
    anio_inicio = models.CharField(max_length=45, blank=True, null=True)
    anio_fin = models.CharField(max_length=45, blank=True, null=True)
    matricula = models.ForeignKey(Alumno, models.DO_NOTHING, db_column='matricula')

    class Meta:
        managed = False
        db_table = 'continuacion_estudios'


class DesempenioRecomendaciones(models.Model):
    id_desempenio_recomendaciones = models.IntegerField(primary_key=True)
    nivel_satisfaccion = models.CharField(max_length=45, choices=NIVEL_SATISFACCION, null=True, blank=True)
    grado_exigencia = models.CharField(max_length=45, choices=GRADO_EXIGENCIA, null=True, blank=True)
    nivel_formacion = models.CharField(max_length=45, choices=NIVEL_FORMACION, null=True, blank=True)
    modificaciones_planest = models.CharField(max_length=45, blank=True, null=True)
    opinion_orgainst = models.CharField(max_length=45, blank=True, null=True)
    matricula = models.ForeignKey(Alumno, models.DO_NOTHING, db_column='matricula')

    class Meta:
        managed = False
        db_table = 'desempenio_recomendaciones'


class DjangoAdminLog(models.Model):
    action_time = models.DateTimeField()
    object_id = models.TextField(blank=True, null=True)
    object_repr = models.CharField(max_length=200)
    action_flag = models.PositiveSmallIntegerField()
    change_message = models.TextField()
    content_type = models.ForeignKey('DjangoContentType', models.DO_NOTHING, blank=True, null=True)
    user = models.ForeignKey(AuthUser, models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'django_admin_log'


class DjangoContentType(models.Model):
    app_label = models.CharField(max_length=100)
    model = models.CharField(max_length=100)

    class Meta:
        managed = False
        db_table = 'django_content_type'
        unique_together = (('app_label', 'model'),)


class DjangoMigrations(models.Model):
    app = models.CharField(max_length=255)
    name = models.CharField(max_length=255)
    applied = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_migrations'


class DjangoSession(models.Model):
    session_key = models.CharField(primary_key=True, max_length=40)
    session_data = models.TextField()
    expire_date = models.DateTimeField()

    class Meta:
        managed = False
        db_table = 'django_session'


class EmpleoInmediato(models.Model):
    id_empleo_inmediato = models.IntegerField(primary_key=True)
    trabajo_ultimoanio = models.CharField(max_length=45, blank=True, null=True)
    coincidencia_trabajoest = models.CharField(max_length=45, choices=MEDIDA_COINCIDENCIA_ESTUDIOS, null=True, blank=True)
    horas_lab_semanales = models.CharField(max_length=45, blank=True, null=True)
    trabajo_finlic = models.CharField(max_length=45, blank=True, null=True)
    busqueda_trab_finlic = models.CharField(max_length=45, blank=True, null=True)
    tiempo_primerempleo = models.CharField(max_length=45, choices=TIEMPO_CONSEGUIR_EMPLEO, null=True, blank=True)
    razon_dificultad_primerempleo = models.CharField(max_length=45, choices=RAZON_NO_EMPLEO, null=True, blank=True)
    medio_conseguir_empleo = models.CharField(max_length=45, choices=MEDIO_EMPLEO, null=True)
    requisito_formal_empleo = models.CharField(max_length=45, choices=REQUISITO_FORMAL_EMPLEO, null=True, blank=True)
    puesto_empleo_inmediato = models.CharField(max_length=45, choices=PUESTO_INICIAL, null=True)
    tamano_empresa_inmediata = models.CharField(max_length=45, choices=TAMANIO_EMPRESA_INMEDIATA, null=True, blank=True)
    regimen_juridico = models.CharField(max_length=45, choices=REGIMEN_JURIDICO, null=True, blank=True)
    ingreso_mensual_neto_inicio = models.CharField(db_column='ingreso_mensual_neto_Inicio', max_length=45, blank=True, null=True)  # Field name made lowercase.
    anio = models.CharField(max_length=45, blank=True, null=True)
    horas_laboral_semanales = models.CharField(max_length=45, blank=True, null=True)
    duracion_trabajo = models.CharField(max_length=45, blank=True, null=True)
    sector_economico = models.CharField(max_length=45, choices=SECTOR_ECONOMICO, null=True, blank=True)
    razon_nobusqueda_empleo = models.CharField(max_length=45, choices=RAZON_NO_EMPLEO, null=True, blank=True)
    matricula = models.ForeignKey(Alumno, models.DO_NOTHING, db_column='matricula')

    class Meta:
        managed = False
        db_table = 'empleo_inmediato'


class Empresa(models.Model):
    id_empresa = models.IntegerField(primary_key=True)
    nombre_empresa = models.CharField(max_length=45, blank=True, null=True)
    calle_empresa = models.CharField(max_length=45, blank=True, null=True)
    colonia_empresa = models.CharField(max_length=45, blank=True, null=True)
    num_empresa = models.CharField(max_length=45, blank=True, null=True)
    codigo_postal = models.CharField(max_length=45, blank=True, null=True)
    departamento = models.CharField(max_length=45, choices=DEPARTAMENTOS, null=True, blank=True)
    id_estado = models.ForeignKey('Estados', models.DO_NOTHING, db_column='id_estado', blank=True, null=True)
    id_municipio = models.ForeignKey('Municipios', models.DO_NOTHING, db_column='id_municipio', blank=True, null=True)
    puesto = models.CharField(max_length=45, choices=PUESTO_INICIAL, null=True, blank=True)
    tipo_contratacion = models.CharField(max_length=45, choices=TIPO_CONTRATACION, null=True, blank=True)
    regimen_juridico = models.CharField(max_length=45, choices=REGIMEN_JURIDICO, null=True, blank=True)
    ingresomensual_neto = models.CharField(max_length=45, blank=True, null=True)
    horas_laborales = models.CharField(max_length=45, blank=True, null=True)
    fecha_inicio = models.CharField(max_length=45, blank=True, null=True)
    medida_coincidencia_labestudios = models.CharField(max_length=45, choices=MEDIDA_COINCIDENCIA_ESTUDIOS, null=True, blank=True)
    sector_economico = models.CharField(max_length=45, choices=SECTOR_ECONOMICO, null=True, blank=True)
    otro_empleo = models.CharField(max_length=45, blank=True, null=True)
    matricula = models.ForeignKey(Alumno, models.DO_NOTHING, db_column='matricula')

    class Meta:
        managed = False
        db_table = 'empresa'


class Estados(models.Model):
    id_estado = models.AutoField(primary_key=True)
    estado = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        return self.estado

    class Meta:
        managed = False
        db_table = 'estados'


class Licenciatura(models.Model):
    id_licenciatura = models.IntegerField(primary_key=True)
    nombre_campus = models.CharField(max_length=45, validators=[just_number], null=True, blank=True)
    nombre_carrera = models.CharField(max_length=45, blank=True)
    anio_pestudios = models.CharField(max_length=45, blank=True, null=True)
    anio_inicio = models.CharField(max_length=25, blank=True, null=True)
    anio_fin = models.CharField(max_length=25, blank=True, null=True)
    org_ss = models.CharField(max_length=45, blank=True, null=True)
    fecha_inicioss = models.DateField(blank=True, null=True)
    fecha_finss = models.DateField(blank=True, null=True)
    titulado = models.CharField(max_length=10, choices=TITULADO_CHOICES, null=True, blank=True)
    promedio_final = models.CharField(max_length=10, blank=True, null=True)
    tipo_inscripcion = models.CharField(max_length=25, choices=TIPOINSCRIPCION, null=True, blank=True)
    matricula = models.ForeignKey(Alumno, models.DO_NOTHING, db_column='matricula')

    class Meta:
        managed = False
        db_table = 'licenciatura'


class Municipios(models.Model):
    id_municipio = models.AutoField(primary_key=True)
    nombre_municipio = models.CharField(max_length=100)
    id_estado = models.IntegerField()

    def __str__(self):
        return self.nombre_municipio

    class Meta:
        managed = False
        db_table = 'municipios'


class SeleccionCarrera(models.Model):
    id_seleccion_carrera = models.IntegerField(primary_key=True)
    primera_opcioncarrera = models.CharField(max_length=45, blank=True, null=True, choices=PRIMERAOPCION_CHOICES)
    eleccion_tipoinstitucion = models.CharField(max_length=45,  null=True, choices=TIPO_INSTITUCION, blank=True)
    primera_eleccion = models.CharField(max_length=45, blank=True, null=True)
    seleccion_carreracol = models.CharField(max_length=45, blank=True, null=True)
    primera_eleccionnombre = models.CharField(max_length=45, blank=True, null=True)
    razon_eleccioninstitucion = models.CharField(max_length=45, blank=True, null=True)
    razon_eleccioncarrera = models.CharField(max_length=45, blank=True, null=True)
    matricula = models.ForeignKey(Alumno, models.DO_NOTHING, db_column='matricula')

    class Meta:
        managed = False
        db_table = 'seleccion_carrera'
