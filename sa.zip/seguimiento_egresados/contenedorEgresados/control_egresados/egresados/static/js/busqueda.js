$(document).ready(function(){
                 $('select#id_estado').change(function () {
                     var optionSelected = $(this).find("option:selected");
                     var valueSelected  = optionSelected.val();
                     var estado_name   = optionSelected.text();


                     data = {'est' : estado_name };
                     ajax('/getdetails',data,function(result){
                            $("#id_municipio option").remove();
                            for (var i = result.length - 1; i >= 0; i--) {
                                $("#id_municipio").append('<option>'+ result[i].name +'</option>');
                            };


                         });
                 });
            });