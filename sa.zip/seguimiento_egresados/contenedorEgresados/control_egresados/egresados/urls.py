from django.contrib import admin
from control_egresados import settings
from django.urls import path
from django.conf.urls import url
from .views import *


app_name="egresados"

urlpatterns = [
    path('%sinicio/' % settings.PATH_PREFIX, inicio, name='inicio'),
    path('%sinicio/' % settings.PATH_PREFIX, salir, name='salir'),
    path('%s' % settings.PATH_PREFIX, bienvenida, name='bienvenida'),
    path('%seditAlumno/' % settings.PATH_PREFIX, edit_alumno, name='edit_alumno'),
    path('%screateAlumno/' % settings.PATH_PREFIX, create_alumno, name='create_alumno'),
    path('%seditSeleccionCarrera/' % settings.PATH_PREFIX, edit_seleccion_carrera, name='edit_seleccion_carrera'),
    path('%screateSeleccionCarrera/' % settings.PATH_PREFIX, create_seleccion_carrera, name='create_seleccion_carrera'),
    path('%seditLicenciatura/' % settings.PATH_PREFIX, edit_licenciatura, name='edit_licenciatura'),
    path('%screateLicenciatura/' % settings.PATH_PREFIX, create_licenciatura, name='create_licenciatura'),
    path('%seditContinuacionEstudios/' % settings.PATH_PREFIX, edit_continuacion_estudios, name='edit_continuacion_estudios'),
    path('%screateContinuacionEstudios/' % settings.PATH_PREFIX, create_continuacion_estudios, name='create_continuacion_estudios'),
    path('%seditEmpleoInmediato/' % settings.PATH_PREFIX, edit_empleo_inmediato, name='edit_empleo_inmediato'),
    path('%screateEmpleoInmediato/' % settings.PATH_PREFIX, create_empleo_inmediato, name='create_empleo_inmediato'),
    path('%seditEmpleoActual/' % settings.PATH_PREFIX, edit_empleo_actual, name='edit_empleo_actual'),
    path('%screateEmpleoActual/' % settings.PATH_PREFIX, create_empleo_actual, name='create_empleo_actual'),
    path('%seditRecomendaciones/' % settings.PATH_PREFIX, edit_recomendaciones, name='edit_recomendaciones'),
    path('%screateRecomendaciones/' % settings.PATH_PREFIX, create_recomendaciones, name='create_recomendaciones'),

    path('%sdetalleAlumno/' % settings.PATH_PREFIX, detalle_alumno, name='detalle_alumno'),
    path('%slicenciatura/' % settings.PATH_PREFIX, licenciatura, name='licenciatura'),
    path('%scontinuacionEstudios/' % settings.PATH_PREFIX, continuacion_estudios, name='continuacion_estudios'),
    path('%sseleccionCarrera/' % settings.PATH_PREFIX, seleccion_carrera, name='seleccion_carrera'),
    path('%sempleoInmediato/' % settings.PATH_PREFIX, empleo_inmediato, name='empleo_inmediato'),
    path('%sempleoActual/' % settings.PATH_PREFIX, empleo_actual, name='empleo_actual'),
    path('%srecomendaciones/' % settings.PATH_PREFIX, recomendaciones, name='recomendaciones'),
    #path('getdetails/', getdetails, name='getdetails'),
   
]